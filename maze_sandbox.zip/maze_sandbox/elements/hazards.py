import math
import config

class HazardManager:
    def __init__(self, grid):
        self.grid = grid
        self.hazards = []

    def add_hazard(self, cell, radius=2, patrol_path=None):
        hazard = {
            "cell": cell,
            "radius": radius,
            "patrol_path": patrol_path or [],
            "path_index": 0,
            "timer": 0.0,
            "move_interval": 0.5
        }
        cell.make_hazard(radius)
        if hazard not in self.hazards:
            self.hazards.append(hazard)

    def remove_hazard(self, cell):
        self.hazards = [h for h in self.hazards if h["cell"] != cell]
        if cell.type == config.TYPE_HAZARD:
            cell.make_empty()

    def update(self, dt: float):
        for hazard in self.hazards:
            if not hazard["patrol_path"]:
                continue
            
            hazard["timer"] += dt
            if hazard["timer"] >= hazard["move_interval"]:
                hazard["timer"] = 0.0
                hazard["path_index"] = (hazard["path_index"] + 1) % len(hazard["patrol_path"])
                
                old_cell = hazard["cell"]
                new_coords = hazard["patrol_path"][hazard["path_index"]]
                new_cell = self.grid.get_cell(*new_coords)
                
                if new_cell and not new_cell.is_wall:
                    old_cell.make_empty()
                    hazard["cell"] = new_cell
                    new_cell.make_hazard(hazard["radius"])

    def get_danger_zone(self) -> set:
        danger_zone = set()
        for hazard in self.hazards:
            center_cell = hazard["cell"]
            radius = hazard["radius"]
            
            for r in range(center_cell.row - radius, center_cell.row + radius + 1):
                for c in range(center_cell.col - radius, center_cell.col + radius + 1):
                    if self.grid.is_valid_coords(r, c):
                        dist = math.sqrt((r - center_cell.row)**2 + (c - center_cell.col)**2)
                        if dist <= radius:
                            cell = self.grid.get_cell(r, c)
                            if cell:
                                danger_zone.add(cell)
        return danger_zone

    def is_cell_in_danger(self, cell) -> bool:
        return cell in self.get_danger_zone()

    def clear(self):
        for hazard in self.hazards:
            if hazard["cell"].type == config.TYPE_HAZARD:
                hazard["cell"].make_empty()
        self.hazards.clear()