import sys
import os

# Garante acesso ao config
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import config


class InteractiveManager:
    """
    Gerencia a lógica de interação do jogo: Waypoints obrigatórios,
    pares de Chaves e Portas vinculadas por ID/Cor, e Portais de teletransporte.
    """

    def __init__(self, grid):
        self.grid = grid
        if grid is not None:
            grid.interactive_mgr = self

        self.waypoints = []
        self.portals = {}
        self.keys = {}      # Mapeia {cell: key_id}
        self.doors = {}     # Mapeia {cell: door_id}
        
        self.current_pair_id = 1
        self._next_key_id = 1
        self._next_door_id = 1

    # ==========================================
    # --- GERENCIAMENTO DE WAYPOINTS -----------
    # ==========================================
    def add_waypoint(self, cell, order=None):
        """Adiciona ou remove (toggle) um ponto de passagem obrigatório."""
        if not cell:
            return
        
        # Se a célula já for este waypoint, remove ao clicar novamente (toggle)
        if cell in self.waypoints:
            self.remove_waypoint(cell)
            return

        # Limpa outros tipos interativos da célula antes de converter em waypoint
        self.remove_element_at(cell)

        if order is None:
            order = len(self.waypoints) + 1

        cell.make_waypoint(order)
        self.waypoints.append(cell)
        self._reorder_waypoints()

    def remove_waypoint(self, cell):
        """Remove o waypoint e reordena a sequência."""
        if cell in self.waypoints:
            self.waypoints.remove(cell)
            cell.make_empty()
            self._reorder_waypoints()

    def _reorder_waypoints(self):
        """Reordena a sequência numérica visual de 1 até N."""
        for idx, cell in enumerate(self.waypoints):
            cell.waypoint_order = idx + 1

    def get_ordered_waypoints(self) -> list:
        """Retorna a lista ordenada de pontos de passagem obrigatórios."""
        return sorted(self.waypoints, key=lambda c: getattr(c, 'waypoint_order', 0) or 0)

    # ==========================================
    # --- GERENCIAMENTO DE CHAVES E PORTAS -----
    # ==========================================
    def add_key(self, cell, key_id=None):
        """Adiciona ou alterna uma chave vinculada ao ID do par."""
        if not cell:
            return
        
        if key_id is None:
            key_id = self.current_pair_id

        # Se já for uma chave do mesmo ID, remove (toggle)
        if cell in self.keys and self.keys[cell] == key_id:
            self.remove_key(cell)
            return

        self.remove_element_at(cell)
        cell.make_key(key_id)
        self.keys[cell] = key_id

    def remove_key(self, cell):
        """Remove uma chave da grade."""
        if cell in self.keys:
            del self.keys[cell]
        cell.make_empty()

    def add_door(self, cell, door_id=None):
        """Adiciona ou alterna uma porta vinculada ao ID do par."""
        if not cell:
            return

        if door_id is None:
            door_id = self.current_pair_id

        # Se já for uma porta do mesmo ID, remove (toggle)
        if cell in self.doors and self.doors[cell] == door_id:
            self.remove_door(cell)
            return

        self.remove_element_at(cell)
        cell.make_door(door_id)
        self.doors[cell] = door_id

    def remove_door(self, cell):
        """Remove uma porta da grade."""
        if cell in self.doors:
            del self.doors[cell]
        cell.make_empty()

    def can_unlock_door(self, door_cell, collected_keys) -> bool:
        """
        Verifica se o jogador/algoritmo possui a chave correspondente ao ID da porta.
        """
        if not door_cell:
            return True
        door_id = getattr(door_cell, 'door_id', None)
        if door_id is None:
            door_id = self.doors.get(door_cell, None)
        if door_id is None:
            return True
        return door_id in collected_keys

    # ==========================================
    # --- GERENCIAMENTO DE PORTAIS -------------
    # ==========================================
    def add_portal(self, cell_a, cell_b=None):
        """Adiciona um portal vinculado entre dois pontos."""
        if not cell_a:
            return

        if cell_b is None:
            unpaired_portals = [c for c in self._get_all_portal_cells() if c not in self.portals]
            if unpaired_portals:
                cell_b = unpaired_portals[0]
                self.portals[cell_a] = cell_b
                self.portals[cell_b] = cell_a
                cell_a.make_portal((cell_b.row, cell_b.col))
                cell_b.make_portal((cell_a.row, cell_a.col))
            else:
                cell_a.make_portal(None)
        else:
            self.portals[cell_a] = cell_b
            self.portals[cell_b] = cell_a
            cell_a.make_portal((cell_b.row, cell_b.col))
            cell_b.make_portal((cell_a.row, cell_a.col))

    def remove_portal(self, cell):
        """Remove um portal e desvincula seu par se existir."""
        if cell in self.portals:
            target_cell = self.portals[cell]
            del self.portals[cell]
            if target_cell in self.portals:
                del self.portals[target_cell]
            target_cell.make_empty()
        cell.make_empty()

    def get_portal_destination(self, cell):
        return self.portals.get(cell, None)

    def _get_all_portal_cells(self):
        portal_cells = []
        for r in range(self.grid.rows):
            for c in range(self.grid.cols):
                cell = self.grid.get_cell(r, c)
                if cell and getattr(cell, 'type', None) == getattr(config, 'TYPE_PORTAL', 7):
                    portal_cells.append(cell)
        return portal_cells

    # ==========================================
    # --- LIMPEZA E AÇÕES GENÉRICAS ------------
    # ==========================================
    def remove_element_at(self, cell):
        """Remove qualquer elemento interativo associado a uma célula."""
        if not cell:
            return

        if cell in self.waypoints:
            self.remove_waypoint(cell)
        if cell in self.portals or cell in self._get_all_portal_cells():
            self.remove_portal(cell)
        if cell in self.keys:
            self.remove_key(cell)
        if cell in self.doors:
            self.remove_door(cell)

    def clear(self):
        """Reseta e remove todos os elementos interativos."""
        for cell in list(self.waypoints):
            cell.make_empty()
        for cell in list(self.keys.keys()):
            cell.make_empty()
        for cell in list(self.doors.keys()):
            cell.make_empty()
        for cell in list(self.portals.keys()):
            cell.make_empty()

        self.waypoints.clear()
        self.portals.clear()
        self.keys.clear()
        self.doors.clear()
        
        self.current_pair_id = 1
        self._next_key_id = 1
        self._next_door_id = 1