import sys
import os
import inspect
import pygame

# Garante o diretório raiz no PATH do sistema
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import config
from core.camera import Camera
from core.grid import Grid
from elements.hazards import HazardManager
from elements.interactive import InteractiveManager
from algorithms.generation import MazeGenerator
from algorithms.pathfinding import PathfindingManager
from ui.interface import InterfaceManager
from ui.renderer import Renderer
from utils.file_manager import FileManager
from core.real_map import RealMapGraph


class UltimateMazeSandbox:
    """
    Classe principal controladora do aplicativo Ultimate Maze Sandbox.
    """

    def __init__(self):
        pygame.init()
        pygame.font.init()

        # Resolução e Janela principal (com fallback seguro para atributos do config)
        self.screen_width = getattr(config, 'WINDOW_WIDTH', getattr(config, 'SCREEN_WIDTH', 1280))
        self.screen_height = getattr(config, 'WINDOW_HEIGHT', getattr(config, 'SCREEN_HEIGHT', 720))

        self.screen = pygame.display.set_mode(
            (self.screen_width, self.screen_height),
            pygame.RESIZABLE | pygame.DOUBLEBUF
        )
        pygame.display.set_caption("Ultimate Maze Sandbox - inc.gulosinhos_games")
        
        self.clock = pygame.time.Clock()
        self.is_running = True

        # 1. Componentes do Núcleo
        default_rows = getattr(config, 'DEFAULT_GRID_ROWS', 30)
        default_cols = getattr(config, 'DEFAULT_GRID_COLS', 40)
        self.grid = Grid(rows=default_rows, cols=default_cols)
        self.camera = Camera(self.screen_width, self.screen_height)

        # 2. Elementos de Jogo e Perigos
        self.interactive_mgr = InteractiveManager(self.grid)
        self.hazard_mgr = HazardManager(self.grid)

        # 3. Algoritmos de Geração e Busca
        self.generator = MazeGenerator(self.grid)
        self.pathfinding = PathfindingManager(
            grid=self.grid,
            interactive_mgr=self.interactive_mgr,
            hazard_mgr=self.hazard_mgr
        )

        # 4. Interface, Renderização, Persistência e Modo Mapa Real
        self.file_mgr = FileManager()
        self.real_map = RealMapGraph()
        self.ui_mgr = InterfaceManager(
            window_width=self.screen_width,
            window_height=self.screen_height,
            grid=self.grid,
            pathfinding_mgr=self.pathfinding,
            maze_gen_mgr=self.generator
        )
        self.renderer = Renderer(
            screen=self.screen,
            camera=self.camera,
            grid=self.grid,
            ui_manager=self.ui_mgr,
            real_map=self.real_map
        )

        # Garante referências integradas para reset completo e sincronização
        self.grid.interactive_mgr = self.interactive_mgr
        self.grid.hazard_mgr = self.hazard_mgr
        self.ui_mgr.interactive_mgr = self.interactive_mgr
        self.ui_mgr.set_real_map(self.real_map)
        # Conecta o renderer à UI para que os controles de visão funcionem
        if hasattr(self.ui_mgr, 'set_renderer'):
            self.ui_mgr.set_renderer(self.renderer)

        # Pré-carrega o mapa padrão em background para carregamento rápido
        if hasattr(self.ui_mgr, '_load_preset'):
            self.ui_mgr._load_preset("Avenida Paulista, SP")

        # Controle de Estados de Mouse e Câmera
        self.is_panning = False
        self.pan_start_pos = (0, 0)
        self.is_mouse_down = False
        self.mouse_button = None
        self.is_orbit_rotating = False   # Botão direito arrastado no modo 3D Orbital
        self.orbit_last_pos = (0, 0)


        self._setup_default_map()

    def _setup_default_map(self):
        """Inicializa as células de entrada e saída padrão na grade."""
        if hasattr(self.grid, 'set_start_cell'):
            self.grid.set_start_cell(1, 1)
        elif hasattr(self.grid, 'start_cell'):
            cell = self.grid.get_cell(1, 1)
            if cell:
                cell.make_start()
                self.grid.start_cell = cell

        if hasattr(self.grid, 'add_end_cell'):
            self.grid.add_end_cell(self.grid.rows - 2, self.grid.cols - 2)
        elif hasattr(self.grid, 'end_cells'):
            cell = self.grid.get_cell(self.grid.rows - 2, self.grid.cols - 2)
            if cell:
                cell.make_end()
                if cell not in self.grid.end_cells:
                    self.grid.end_cells.append(cell)

    def safe_call_generator(self, method_name: str):
        """Executa os métodos do gerador tratando parâmetros obrigatórios dinamicamente."""
        method = getattr(self.generator, method_name, None)
        if not method or not callable(method):
            return

        sig = inspect.signature(method)
        params = sig.parameters

        # Garante o envio da célula inicial se a função exigir parâmetros
        if len(params) > 0:
            start_node = getattr(self.grid, 'start_cell', None) or self.grid.get_cell(1, 1)
            method(start_node)
        else:
            method()

    def handle_events(self):
        """Processa eventos do teclado, mouse e redimensionamento."""
        keys = pygame.key.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.is_running = False
                return

            elif event.type == pygame.VIDEORESIZE:
                self.screen_width, self.screen_height = event.w, event.h
                self.screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE | pygame.DOUBLEBUF)
                if hasattr(self.camera, 'update_viewport'):
                    self.camera.update_viewport(event.w, event.h)
                elif hasattr(self.camera, 'handle_resize'):
                    self.camera.handle_resize(event.w, event.h)

            # Delega eventos do minimapa primeiro (modo 3D/1ª Pessoa)
            if hasattr(self.renderer, 'handle_minimap_event'):
                if self.renderer.handle_minimap_event(event):
                    continue

            # Delega cliques à Interface do Usuário (UI)
            if hasattr(self.ui_mgr, 'handle_event') and self.ui_mgr.handle_event(event):
                continue

            # ------------------------------------------------------------------
            # Atalhos globais do Teclado
            # ------------------------------------------------------------------
            app_mode = getattr(self.ui_mgr, 'app_mode', 'MAZE')

            if event.type == pygame.KEYDOWN:
                if app_mode == 'REAL_MAP':
                    if event.key == pygame.K_SPACE:
                        self.ui_mgr._map_play()
                    elif event.key == pygame.K_r:
                        self.ui_mgr._map_reset()
                    elif event.key == pygame.K_c:
                        self.ui_mgr._map_center_view()
                    elif event.key == pygame.K_n:
                        self.ui_mgr._map_toggle_nav()
                else:
                    cam_mode = getattr(self.camera, 'mode', '2D')

                    # F3: Cicla entre os modos de visão
                    if event.key == pygame.K_F3:
                        if hasattr(self.renderer, 'toggle_3d_mode'):
                            self.renderer.toggle_3d_mode()
                        # Sincroniza o dropdown de visão com o novo modo
                        if hasattr(self.ui_mgr, 'dd_view') and hasattr(self.renderer, 'camera'):
                            mode_to_idx = {'2D': 0, '3D_ORBIT': 1, 'FIRST_PERSON': 2}
                            new_idx = mode_to_idx.get(getattr(self.camera, 'mode', '2D'), 0)
                            self.ui_mgr.dd_view.selected_index = new_idx

                    # M: Liga/desliga o Minimapa
                    elif event.key == pygame.K_m:
                        if hasattr(self.renderer, 'toggle_minimap'):
                            self.renderer.toggle_minimap()
                        if hasattr(self.ui_mgr, 'btn_minimap'):
                            show = getattr(self.renderer, 'show_minimap', True)
                            self.ui_mgr.btn_minimap.text = "Minimapa: ON" if show else "Minimapa: OFF"

                    # Controles do modo PRIMEIRA PESSOA (WASD + Setas)
                    elif cam_mode == 'FIRST_PERSON':
                        if event.key in (pygame.K_w, pygame.K_UP):
                            self.camera.move_forward(self.grid, self.interactive_mgr)
                        elif event.key in (pygame.K_s, pygame.K_DOWN):
                            self.camera.move_backward(self.grid, self.interactive_mgr)
                        elif event.key in (pygame.K_a, pygame.K_LEFT):
                            self.camera.turn_left()
                        elif event.key in (pygame.K_d, pygame.K_RIGHT):
                            self.camera.turn_right()

                    # Atalhos gerais do labirinto
                    elif event.key == pygame.K_SPACE:
                        if hasattr(self.pathfinding, 'toggle_start'):
                            self.pathfinding.toggle_start()
                        elif hasattr(self.pathfinding, 'start'):
                            self.pathfinding.start()
                    elif event.key == pygame.K_r:
                        if hasattr(self.pathfinding, 'reset'):
                            self.pathfinding.reset()
                    elif event.key == pygame.K_c:
                        if hasattr(self.ui_mgr, '_clear_all_maze'):
                            self.ui_mgr._clear_all_maze()
                        else:
                            self.grid.fill_empty(self.interactive_mgr)
                            self.pathfinding.reset()

            # ------------------------------------------------------------------
            # Controle de Zoom via Scroll do Mouse
            # ------------------------------------------------------------------
            elif event.type == pygame.MOUSEWHEEL:
                mouse_pos = pygame.mouse.get_pos()
                sidebar_w = getattr(self.ui_mgr, 'sidebar_width', 0)
                if mouse_pos[0] > sidebar_w:
                    if app_mode == 'REAL_MAP' and hasattr(self, 'real_map'):
                        vp_rect = pygame.Rect(sidebar_w, 0, max(10, self.screen_width - sidebar_w), self.screen_height)
                        factor = 1.18 if event.y > 0 else (1.0 / 1.18)
                        self.real_map.zoom(factor, mouse_pos[0], mouse_pos[1], vp_rect)
                    elif hasattr(self.camera, 'zoom'):
                        self.camera.zoom(event.y, mouse_pos[0], mouse_pos[1])

            # ------------------------------------------------------------------
            # Processamento de cliques do Mouse
            # ------------------------------------------------------------------
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                sidebar_w = getattr(self.ui_mgr, 'sidebar_width', 0)

                if mouse_pos[0] <= sidebar_w:
                    continue

                if app_mode == 'REAL_MAP' and hasattr(self, 'real_map'):
                    vp_rect = pygame.Rect(sidebar_w, 0, max(10, self.screen_width - sidebar_w), self.screen_height)
                    if event.button == 1:
                        # Clique esquerdo: seleciona nó de Início (A) ou inicia Pan
                        clicked_node = self.real_map.find_nearest_node(mouse_pos, vp_rect, max_dist_px=22.0)
                        if clicked_node:
                            if self.real_map.start_node is None or (self.real_map.start_node is not None and self.real_map.end_node is not None):
                                self.real_map.start_node = clicked_node
                                if self.real_map.end_node == clicked_node:
                                    self.real_map.end_node = None
                            else:
                                self.real_map.end_node = clicked_node
                            self.real_map.reset_pathfinding()
                        else:
                            self.is_panning = True
                            self.pan_start_pos = mouse_pos
                    elif event.button == 3:
                        # Clique direito: seleciona nó de Destino (B) ou inicia Pan
                        clicked_node = self.real_map.find_nearest_node(mouse_pos, vp_rect, max_dist_px=22.0)
                        if clicked_node:
                            self.real_map.end_node = clicked_node
                            if self.real_map.start_node == clicked_node:
                                self.real_map.start_node = None
                            self.real_map.reset_pathfinding()
                        else:
                            self.is_panning = True
                            self.pan_start_pos = mouse_pos
                    elif event.button == 2:
                        self.is_panning = True
                        self.pan_start_pos = mouse_pos
                    continue

                # Modo Clássico Labirinto
                cam_mode = getattr(self.camera, 'mode', '2D')

                # Botão direito em 3D Orbital: inicia rotação
                if event.button == 3 and cam_mode == '3D_ORBIT':
                    self.is_orbit_rotating = True
                    self.orbit_last_pos = mouse_pos
                    continue

                if event.button == 2 or (event.button == 1 and keys[pygame.K_SPACE]):
                    self.is_panning = True
                    self.pan_start_pos = mouse_pos
                elif event.button in (1, 3):
                    # Em modo 3D não permite edição de células
                    if cam_mode == '2D':
                        self.is_mouse_down = True
                        self.mouse_button = event.button
                        self.handle_grid_interaction(mouse_pos, is_initial_click=True)

            elif event.type == pygame.MOUSEBUTTONUP:
                if app_mode == 'REAL_MAP':
                    if event.button in (1, 2, 3):
                        self.is_panning = False
                    continue

                if event.button == 3 and self.is_orbit_rotating:
                    self.is_orbit_rotating = False
                elif event.button in (1, 3):
                    self.is_mouse_down = False
                    self.mouse_button = None
                elif event.button == 2 or event.button == 1:
                    self.is_panning = False

            elif event.type == pygame.MOUSEMOTION:
                mouse_pos = pygame.mouse.get_pos()
                sidebar_w = getattr(self.ui_mgr, 'sidebar_width', 0)

                if app_mode == 'REAL_MAP' and hasattr(self, 'real_map'):
                    if mouse_pos[0] > sidebar_w:
                        vp_rect = pygame.Rect(sidebar_w, 0, max(10, self.screen_width - sidebar_w), self.screen_height)
                        if self.is_panning:
                            dx = mouse_pos[0] - self.pan_start_pos[0]
                            dy = mouse_pos[1] - self.pan_start_pos[1]
                            self.real_map.pan(dx, dy)
                            self.pan_start_pos = mouse_pos
                        else:
                            self.real_map.hovered_node = self.real_map.find_nearest_node(mouse_pos, vp_rect, max_dist_px=22.0)
                    continue

                cam_mode = getattr(self.camera, 'mode', '2D')

                # Rotação orbital com botão direito
                if self.is_orbit_rotating:
                    dx = mouse_pos[0] - self.orbit_last_pos[0]
                    dy = mouse_pos[1] - self.orbit_last_pos[1]
                    if hasattr(self.camera, 'rotate_orbit'):
                        self.camera.rotate_orbit(dx * 0.01, dy * 0.01)
                    self.orbit_last_pos = mouse_pos

                elif self.is_panning:
                    dx = mouse_pos[0] - self.pan_start_pos[0]
                    dy = mouse_pos[1] - self.pan_start_pos[1]
                    if cam_mode == '3D_ORBIT' and hasattr(self.camera, 'pan_orbit'):
                        self.camera.pan_orbit(dx, dy)
                    elif hasattr(self.camera, 'pan'):
                        self.camera.pan(dx, dy)
                    self.pan_start_pos = mouse_pos

                elif self.is_mouse_down and mouse_pos[0] > sidebar_w and cam_mode == '2D':
                    self.handle_grid_interaction(mouse_pos, is_initial_click=False)

    def handle_grid_interaction(self, mouse_pos, is_initial_click=False):
        """Aplica ferramentas de edição diretamente nas células da grade."""
        if self.is_panning:
            return

        world_x, world_y = self.camera.screen_to_world(*mouse_pos)
        
        if hasattr(self.grid, 'get_cell_at_world_pos'):
            cell = self.grid.get_cell_at_world_pos(world_x, world_y)
        else:
            cell_size = getattr(config, 'CELL_SIZE', 20)
            col = int(world_x // cell_size)
            row = int(world_y // cell_size)
            cell = self.grid.get_cell(row, col)

        if not cell:
            return

        active_tool = getattr(self.ui_mgr, 'active_tool', 'WALL')
        tool_to_apply = "ERASER" if self.mouse_button == 3 else active_tool

        if hasattr(self.grid, 'apply_tool'):
            pair_id = getattr(self.ui_mgr, 'current_pair_id', 1)
            self.grid.apply_tool(cell, tool_to_apply, self.interactive_mgr, self.hazard_mgr, pair_id=pair_id)

    def update(self, delta_time: float):
        """Atualização temporal da simulação de perigos, busca e interface."""
        if hasattr(self.hazard_mgr, 'update'):
            self.hazard_mgr.update(delta_time)
            
        if hasattr(self.pathfinding, 'update'):
            self.pathfinding.update(delta_time)
        
        if hasattr(self.ui_mgr, 'update'):
            try:
                self.ui_mgr.update(delta_time)
            except TypeError:
                self.ui_mgr.update()

    def render(self):
        """Renderiza a grade 2D/3D e a interface do usuário na tela."""
        bg_color = getattr(config, 'COLOR_BG', (20, 23, 30))
        self.screen.fill(bg_color)

        if hasattr(self.renderer, 'render_world'):
            self.renderer.render_world()
            
        if hasattr(self.renderer, 'render_ui'):
            self.renderer.render_ui()

        pygame.display.flip()

    def run(self):
        """Loop principal do jogo (Game Loop)."""
        target_fps = getattr(config, 'TARGET_FPS', 60)
        
        while self.is_running:
            delta_time = self.clock.tick(target_fps) / 10.0
            self.handle_events()
            self.update(delta_time)
            self.render()

        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    app = UltimateMazeSandbox()
    app.run()