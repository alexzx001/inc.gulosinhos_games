import sys
import os
import random

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import config


class MazeGenerator:
    """
    Gerenciador de algoritmos para geração automática e aleatória de labirintos.
    Suporta DFS (Backtracker), Prim, Divisão Recursiva e Gerador Caótico.
    """

    def __init__(self, grid):
        self.grid = grid

    def generate_dfs(self):
        """Gera um labirinto perfeito utilizando busca em profundidade (DFS / Backtracker)."""
        self.grid.fill_walls()

        start_row = 1 if self.grid.rows > 2 else 0
        start_col = 1 if self.grid.cols > 2 else 0
        
        start_cell = self.grid.get_cell(start_row, start_col)
        if not start_cell:
            return

        stack = [start_cell]
        visited = {start_cell}
        start_cell.make_empty()

        while stack:
            current = stack[-1]
            neighbors = self._get_unvisited_step2_neighbors(current, visited)

            if neighbors:
                neighbor, wall_cell = random.choice(neighbors)
                wall_cell.make_empty()
                neighbor.make_empty()
                visited.add(neighbor)
                stack.append(neighbor)
            else:
                stack.pop()

    def generate_prim(self):
        """Gera um labirinto utilizando a versão adaptada do Algoritmo de Prim."""
        self.grid.fill_walls()

        start_row = 1 if self.grid.rows > 2 else 0
        start_col = 1 if self.grid.cols > 2 else 0

        start_cell = self.grid.get_cell(start_row, start_col)
        if not start_cell:
            return

        start_cell.make_empty()
        walls = self._get_cell_walls(start_cell)

        while walls:
            wall, c1, c2 = random.choice(walls)
            walls.remove((wall, c1, c2))

            c1_empty = not c1.is_wall
            c2_empty = not c2.is_wall

            if c1_empty ^ c2_empty:
                wall.make_empty()
                unvisited = c2 if c1_empty else c1
                unvisited.make_empty()

                for w in self._get_cell_walls(unvisited):
                    if w not in walls:
                        walls.append(w)

    def generate_recursive_division(self):
        """Gera um labirinto escavando paredes por divisão recursiva do espaço."""
        self.grid.fill_empty()
        
        # Cria bordas externas
        for r in range(self.grid.rows):
            for c in range(self.grid.cols):
                if r == 0 or r == self.grid.rows - 1 or c == 0 or c == self.grid.cols - 1:
                    cell = self.grid.get_cell(r, c)
                    if cell and cell != self.grid.start_cell and cell not in self.grid.end_cells:
                        cell.make_wall()

        self._divide(1, 1, self.grid.cols - 2, self.grid.rows - 2)

    def generate_chaos(self, density: float = 0.3):
        """Gera um mapa caótico distribuindo obstáculos de forma aleatória."""
        self.grid.fill_empty()

        for r in range(self.grid.rows):
            for c in range(self.grid.cols):
                cell = self.grid.get_cell(r, c)
                if not cell:
                    continue

                if cell == self.grid.start_cell or cell in self.grid.end_cells:
                    continue

                if random.random() < density:
                    cell.make_wall()

    # Métodos Auxiliares
    def _get_unvisited_step2_neighbors(self, cell, visited):
        neighbors = []
        r, c = cell.row, cell.col
        directions = [(-2, 0), (2, 0), (0, -2), (0, 2)]

        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            target = self.grid.get_cell(nr, nc)
            if target and target not in visited:
                wall_cell = self.grid.get_cell(r + dr // 2, c + dc // 2)
                if wall_cell:
                    neighbors.append((target, wall_cell))

        return neighbors

    def _get_cell_walls(self, cell):
        walls = []
        r, c = cell.row, cell.col
        directions = [(-2, 0), (2, 0), (0, -2), (0, 2)]

        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            target = self.grid.get_cell(nr, nc)
            wall_cell = self.grid.get_cell(r + dr // 2, c + dc // 2)
            if target and wall_cell and wall_cell.is_wall:
                walls.append((wall_cell, cell, target))

        return walls

    def _divide(self, x, y, width, height):
        if width <= 2 or height <= 2:
            return

        horizontal = random.choice([True, False])
        if width > height:
            horizontal = False
        elif height > width:
            horizontal = True

        if horizontal:
            wall_y = y + random.randrange(1, height - 1, 2)
            passage_x = x + random.randrange(0, width, 2)

            for col in range(x, x + width):
                if col != passage_x:
                    cell = self.grid.get_cell(wall_y, col)
                    if cell and cell != self.grid.start_cell and cell not in self.grid.end_cells:
                        cell.make_wall()

            self._divide(x, y, width, wall_y - y)
            self._divide(x, wall_y + 1, width, y + height - wall_y - 1)
        else:
            wall_x = x + random.randrange(1, width - 1, 2)
            passage_y = y + random.randrange(0, height, 2)

            for row in range(y, y + height):
                if row != passage_y:
                    cell = self.grid.get_cell(row, wall_x)
                    if cell and cell != self.grid.start_cell and cell not in self.grid.end_cells:
                        cell.make_wall()

            self._divide(x, y, wall_x - x, height)
            self._divide(wall_x + 1, y, x + width - wall_x - 1, height)


# Alias para garantir compatibilidade de importação
GeneratorManager = MazeGenerator