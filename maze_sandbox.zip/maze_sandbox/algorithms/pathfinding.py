import heapq
import math
from collections import deque
import config


class PathfindingManager:
    """
    Gerenciador de algoritmos de busca (A*, Dijkstra, BFS, DFS) com suporte
    a múltiplos waypoints obrigatórios sequenciais, coleta de chaves com retorno
    por corredores sem saída, destrancamento de portas vinculadas e portais.
    """

    def __init__(self, grid, interactive_mgr=None, hazard_mgr=None):
        self.grid = grid
        self.interactive_mgr = interactive_mgr
        self.hazard_mgr = hazard_mgr

        self.algorithm = "A*"
        self.is_running = False
        self.is_finished = False
        
        self.open_set = []
        self.queue = deque()
        self.stack = []
        self.visited_set = set()
        
        self.current_targets = []
        self.target_index = 0
        self.collected_keys = set()
        self.path = []
        
        self.step_timer = 0.0
        self.step_delay = 0.02
        self.visited_count = 0
        self.path_length = 0

    def set_algorithm(self, algo_name: str):
        self.algorithm = algo_name
        self.reset()

    def set_speed(self, speed_fps: float):
        if speed_fps > 0:
            self.step_delay = 1.0 / speed_fps

    def reset(self):
        self.is_running = False
        self.is_finished = False
        self.open_set.clear()
        self.queue.clear()
        self.stack.clear()
        self.visited_set.clear()
        self.current_targets.clear()
        self.target_index = 0
        self.collected_keys.clear()
        self.path.clear()
        self.visited_count = 0
        self.path_length = 0
        self.grid.reset_pathfinding()

    def start(self):
        self.reset()
        if not self.grid.start_cell:
            return

        self._build_target_sequence()
        if not self.current_targets:
            return

        self.is_running = True
        self._init_search_segment(self.grid.start_cell, self.current_targets[self.target_index])

    def toggle_start(self):
        if self.is_running:
            self.is_running = False
        else:
            if self.is_finished:
                self.start()
            else:
                self.is_running = True

    def _build_target_sequence(self):
        """Constrói a sequência obrigatória: Início -> Waypoint 1 -> ... -> Waypoint N -> Saída."""
        self.current_targets = []
        if self.interactive_mgr and hasattr(self.interactive_mgr, 'get_ordered_waypoints'):
            ordered_wp = self.interactive_mgr.get_ordered_waypoints()
            self.current_targets.extend(ordered_wp)
        elif self.interactive_mgr and getattr(self.interactive_mgr, 'waypoints', None):
            sorted_wp = sorted(self.interactive_mgr.waypoints, key=lambda c: getattr(c, 'waypoint_order', 0) or 0)
            self.current_targets.extend(sorted_wp)

        if self.grid.end_cells:
            self.current_targets.append(self.grid.end_cells[0])

    def _reset_grid_search_states(self):
        """Limpa as variáveis de busca dos nós para um novo segmento, mantendo o traçado do caminho já percorrido."""
        path_set = set(self.path)
        for row in self.grid.grid:
            for cell in row:
                cell.g_cost = float('inf')
                cell.h_cost = 0.0
                cell.f_cost = float('inf')
                cell.parent = None
                cell.visited = False
                cell.is_open = False
                cell.is_path = (cell in path_set)

    def _init_search_segment(self, start_cell, target_cell):
        """Inicializa um novo trecho de busca entre nós."""
        self.open_set.clear()
        self.queue.clear()
        self.stack.clear()
        self.visited_set.clear()

        # Reseta os estados da malha para permitir que o algoritmo saia de becos sem saída
        self._reset_grid_search_states()

        start_cell.g_cost = 0.0
        start_cell.h_cost = self._heuristic(start_cell, target_cell)
        start_cell.f_cost = start_cell.g_cost + start_cell.h_cost
        start_cell.parent = None
        start_cell.visited = False
        start_cell.is_open = True

        if self.algorithm in ["A*", "Dijkstra"]:
            heapq.heappush(self.open_set, (start_cell.f_cost, start_cell))
        elif self.algorithm == "BFS":
            self.queue.append(start_cell)
        elif self.algorithm == "DFS":
            self.stack.append(start_cell)

    def _heuristic(self, cell_a, cell_b) -> float:
        if self.algorithm in ["Dijkstra", "BFS", "DFS"]:
            return 0.0
        return abs(cell_a.row - cell_b.row) + abs(cell_a.col - cell_b.col)

    def step(self) -> bool:
        if not self.is_running or self.is_finished:
            return False

        if self.target_index >= len(self.current_targets):
            self.is_running = False
            self.is_finished = True
            return False

        current_target = self.current_targets[self.target_index]
        current_cell = self._pop_next_node()

        if not current_cell:
            self.is_running = False
            self.is_finished = True
            return False

        current_cell.is_open = False
        current_cell.visited = True
        self.visited_set.add(current_cell)
        self.visited_count += 1

        # 1. Efeito "Sub-Caminho Sem Saída" em Chaves:
        # Se a chave estiver dentro de um corredor sem saída, ao pegá-la e redefinir o ponto
        # de partida como a posição atual da chave, limpamos o estado visited da malha
        # para que o algoritmo consiga sair da sala sem considerar o corredor como um bloqueio.
        if current_cell.type == getattr(config, 'TYPE_KEY', 5):
            key_id = getattr(current_cell, 'key_id', 1) or 1
            if key_id not in self.collected_keys:
                self.collected_keys.add(key_id)
                self._reconstruct_path_segment(current_cell)
                self._init_search_segment(current_cell, current_target)
                return True

        # 2. Verificação de Chegada ao Alvo Atual (Waypoint ou Saída)
        is_target_reached = False
        if current_cell == current_target:
            is_target_reached = True
        elif self.current_targets and self.target_index == len(self.current_targets) - 1:
            if current_cell.is_end or current_cell in self.grid.end_cells:
                is_target_reached = True

        if is_target_reached:
            self._reconstruct_path_segment(current_cell)
            self.target_index += 1
            
            if self.target_index < len(self.current_targets):
                next_target = self.current_targets[self.target_index]
                self._init_search_segment(current_cell, next_target)
            else:
                self.is_running = False
                self.is_finished = True
            return True

        # 3. Expansão dos Nós Vizinhos
        danger_zone = set()
        if self.hazard_mgr and hasattr(self.hazard_mgr, 'get_danger_zone'):
            danger_zone = self.hazard_mgr.get_danger_zone()

        neighbors = self._get_valid_neighbors(current_cell, danger_zone)
        for neighbor in neighbors:
            tentative_g = current_cell.g_cost + 1.0

            if tentative_g < neighbor.g_cost:
                neighbor.parent = current_cell
                neighbor.g_cost = tentative_g
                neighbor.h_cost = self._heuristic(neighbor, current_target)
                neighbor.f_cost = neighbor.g_cost + neighbor.h_cost

                if not neighbor.visited and not neighbor.is_open:
                    neighbor.is_open = True
                    if self.algorithm in ["A*", "Dijkstra"]:
                        heapq.heappush(self.open_set, (neighbor.f_cost, neighbor))
                    elif self.algorithm == "BFS":
                        self.queue.append(neighbor)
                    elif self.algorithm == "DFS":
                        self.stack.append(neighbor)

        return True

    def _pop_next_node(self):
        if self.algorithm in ["A*", "Dijkstra"]:
            while self.open_set:
                _, cell = heapq.heappop(self.open_set)
                if not cell.visited:
                    return cell
            return None
        elif self.algorithm == "BFS":
            while self.queue:
                cell = self.queue.popleft()
                if not cell.visited:
                    return cell
            return None
        elif self.algorithm == "DFS":
            while self.stack:
                cell = self.stack.pop()
                if not cell.visited:
                    return cell
            return None
        return None

    def _get_valid_neighbors(self, cell, danger_zone: set) -> list:
        neighbors = []
        raw_neighbors = self.grid.get_neighbors(cell)

        # Portais conectam células distantes
        if self.interactive_mgr and cell.type == getattr(config, 'TYPE_PORTAL', 7):
            if hasattr(self.interactive_mgr, 'get_portal_destination'):
                portal_dest = self.interactive_mgr.get_portal_destination(cell)
                if portal_dest and not portal_dest.is_wall:
                    raw_neighbors.append(portal_dest)

        for n in raw_neighbors:
            if n.is_wall or n in danger_zone:
                continue

            # Portas exigem a respectiva chave coletada
            if n.type == getattr(config, 'TYPE_DOOR', 6):
                if self.interactive_mgr and hasattr(self.interactive_mgr, 'can_unlock_door'):
                    if not self.interactive_mgr.can_unlock_door(n, self.collected_keys):
                        continue

            neighbors.append(n)

        return neighbors

    def _reconstruct_path_segment(self, end_cell):
        curr = end_cell
        segment = []
        while curr:
            curr.is_path = True
            segment.append(curr)
            curr = curr.parent

        segment.reverse()
        if self.path and segment and self.path[-1] == segment[0]:
            self.path.extend(segment[1:])
        else:
            self.path.extend(segment)
        self.path_length = len(self.path)

    def update(self, dt: float):
        if not self.is_running or self.is_finished:
            return

        self.step_timer += dt
        while self.step_timer >= self.step_delay and self.is_running:
            self.step_timer -= self.step_delay
            self.step()