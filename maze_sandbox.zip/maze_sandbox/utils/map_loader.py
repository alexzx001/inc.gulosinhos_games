"""
map_loader.py — Carregador de mapas reais via OpenStreetMap de alta velocidade.
Usa EXCLUSIVAMENTE bibliotecas nativas do Python (urllib, gzip, json, math, threading, os).
Totalmente compatível, com suporte a compressão Gzip, cache em disco e espelhos Overpass.
"""
import os
import gzip
import json
import math
import urllib.request
import urllib.parse
import threading


NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
OVERPASS_URLS = [
    "https://overpass-api.de/api/interpreter",
    "https://lz4.overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter"
]
TIMEOUT_NOMINATIM = 8
TIMEOUT_OVERPASS = 12

# Arquivo de cache persistente para carregamento instantâneo
CACHE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "saved_mazes")


def tile_key(lat: float, lon: float, grid: float = 0.02) -> str:
    """Return a deterministic cache key for a tile based on latitude/longitude rounded to the nearest grid size."""
    lat_key = round(lat / grid) * grid
    lon_key = round(lon / grid) * grid
    return f"{lat_key:.5f}_{lon_key:.5f}"
CACHE_FILE = os.path.join(CACHE_DIR, "osm_cache.json")
_MEM_CACHE = {}


def _load_cache_from_disk():
    global _MEM_CACHE
    if _MEM_CACHE:
        return
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    _MEM_CACHE.update(data)
        except Exception:
            pass


def _save_cache_to_disk(key: str, payload: dict):
    global _MEM_CACHE
    _MEM_CACHE[key] = payload
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(_MEM_CACHE, f, ensure_ascii=False)
    except Exception:
        pass


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calcula a distância geodésica em metros entre duas coordenadas geográficas."""
    R = 6371000.0  # Raio da Terra em metros
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = (math.sin(delta_phi / 2.0) ** 2 +
         math.cos(phi1) * math.cos(phi2) * (math.sin(delta_lambda / 2.0) ** 2))
    c = 2.0 * math.atan2(math.sqrt(max(0.0, a)), math.sqrt(max(0.0, 1.0 - a)))
    return R * c


def get_coordinates(location_name: str):
    """
    Converte um nome de local em (lat, lon) usando a API pública Nominatim.
    Retorna (lat, lon) ou (None, None).
    """
    params = urllib.parse.urlencode({
        "q": location_name,
        "format": "json",
        "limit": 1,
    })
    url = f"{NOMINATIM_URL}?{params}"
    headers = {
        "User-Agent": "UltimateMazeSandbox/2.5 (Student Project; routing viewer)",
        "Accept": "application/json",
        "Accept-Encoding": "gzip, deflate"
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_NOMINATIM) as resp:
            raw_bytes = resp.read()
            if raw_bytes.startswith(b'\x1f\x8b'):
                raw_bytes = gzip.decompress(raw_bytes)
            data = json.loads(raw_bytes.decode("utf-8"))
        if not data or not isinstance(data, list):
            return None, None
        return float(data[0]["lat"]), float(data[0]["lon"])
    except Exception as e:
        print(f"[MapLoader] Erro ao buscar coordenadas: {e}")
        return None, None


def fetch_street_graph(lat: float, lon: float, radius_meters: int = 550):
    """
    Baixa a malha viária real de trânsito ao redor de (lat, lon) via Overpass API com alta performance.
    Filtra vias veiculares/urbanas essenciais para download ultra rápido (sub-segundo).
    Retorna:
      nodes: {node_id: (lat, lon)}
      edges: [(id_origem, id_destino, distancia_metros, highway_type, nome_rua)]
    """
    # Consulta otimizada focada em malha viária navegável
    query = f"""
[out:json][timeout:15];
(
  way["highway"~"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street)"](around:{radius_meters},{lat},{lon});
);
out body;
>;
out skel qt;
"""
    encoded = urllib.parse.urlencode({"data": query}).encode("utf-8")
    raw = None

    headers = {
        "User-Agent": "UltimateMazeSandbox/2.5 (Fast Road Graph Viewer)",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip, deflate"
    }

    for endpoint in OVERPASS_URLS:
        try:
            req = urllib.request.Request(endpoint, data=encoded, headers=headers)
            with urllib.request.urlopen(req, timeout=TIMEOUT_OVERPASS) as resp:
                raw_bytes = resp.read()
                if raw_bytes.startswith(b'\x1f\x8b'):
                    raw_bytes = gzip.decompress(raw_bytes)
                raw = json.loads(raw_bytes.decode("utf-8"))
            if raw and "elements" in raw and len(raw["elements"]) > 0:
                break
        except Exception as e:
            print(f"[MapLoader] Tentando próximo mirror (falha em {endpoint}: {e})")
            continue

    if not raw or "elements" not in raw:
        return {}, []

    nodes = {}
    ways = []

    for elem in raw.get("elements", []):
        elem_type = elem.get("type")
        if elem_type == "node":
            nodes[elem["id"]] = (float(elem["lat"]), float(elem["lon"]))
        elif elem_type == "way":
            tags = elem.get("tags", {})
            oneway = tags.get("oneway", "no") == "yes"
            hw_type = tags.get("highway", "residential")
            name = tags.get("name", "")
            way_nodes = elem.get("nodes", [])
            if len(way_nodes) >= 2:
                ways.append((way_nodes, oneway, hw_type, name))

    edges = []
    for way_nodes, oneway, hw_type, name in ways:
        for i in range(len(way_nodes) - 1):
            u, v = way_nodes[i], way_nodes[i + 1]
            if u in nodes and v in nodes:
                dist = haversine_distance(nodes[u][0], nodes[u][1], nodes[v][0], nodes[v][1])
                edges.append((u, v, dist, hw_type, name))
                if not oneway:
                    edges.append((v, u, dist, hw_type, name))

    return nodes, edges


class MapLoadThread(threading.Thread):
    """
    Thread assíncrona de download do mapa com cache em memória e em disco para carregamento instantâneo.
    """

    def __init__(self, location_name: str, radius_meters: int = 550):
        super().__init__(daemon=True)
        self.location_name = location_name.strip()
        self.radius_meters = radius_meters
        self.done = False
        self.result = None   # (nodes, edges, center_lat, center_lon)
        self.error = None

    def run(self):
        try:
            cache_key = self.location_name.lower()
            _load_cache_from_disk()

            # 1. Verifica cache persistente para carregamento imediato
            cached = None
            if cache_key in _MEM_CACHE:
                cached = _MEM_CACHE[cache_key]
            else:
                for k, v in _MEM_CACHE.items():
                    if (cache_key and cache_key in k) or (len(k) > 4 and k in cache_key):
                        cached = v
                        break

            if cached:
                nodes = {int(k) if str(k).isdigit() else k: (float(v[0]), float(v[1])) for k, v in cached.get("nodes", {}).items()}
                edges = []
                for e in cached.get("edges", []):
                    u = int(e[0]) if str(e[0]).isdigit() else e[0]
                    v = int(e[1]) if str(e[1]).isdigit() else e[1]
                    dist = float(e[2])
                    hw = e[3] if len(e) > 3 else "residential"
                    name = e[4] if len(e) > 4 else ""
                    edges.append((u, v, dist, hw, name))
                lat = float(cached.get("lat", 0.0))
                lon = float(cached.get("lon", 0.0))
                if nodes and edges:
                    self.result = (nodes, edges, lat, lon)
                    self.done = True
                    return

            # 2. Busca coordenadas no Nominatim
            lat, lon = get_coordinates(self.location_name)
            if lat is None:
                self.error = f"Local não encontrado: '{self.location_name}'"
                return

            # 3. Baixa malha viária via Overpass otimizada
            nodes, edges = fetch_street_graph(lat, lon, self.radius_meters)
            if not nodes or not edges:
                self.error = "Nenhuma rua encontrada nesta área."
                return

            # 4. Salva em cache para futuras consultas instantâneas
            to_cache = {
                "lat": lat,
                "lon": lon,
                "nodes": {str(nid): [coord[0], coord[1]] for nid, coord in nodes.items()},
                "edges": [list(e) for e in edges]
            }
            _save_cache_to_disk(cache_key, to_cache)

            self.result = (nodes, edges, lat, lon)
        except Exception as e:
            self.error = f"Erro ao baixar mapa: {e}"
        finally:
            self.done = True
