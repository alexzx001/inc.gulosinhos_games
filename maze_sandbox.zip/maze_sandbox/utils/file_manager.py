import json
import os
import config

class FileManager:
    """
    Gerenciador responsável por salvar, carregar e exportar o estado
    da grade de labirintos e elementos interativos em arquivos JSON/TXT.
    """

    def __init__(self, default_dir: str = "saved_mazes"):
        self.default_dir = default_dir
        self._ensure_directory_exists()

    def _ensure_directory_exists(self):
        """Garante que a pasta padrão de salvamento exista no diretório do projeto."""
        if not os.path.exists(self.default_dir):
            os.makedirs(self.default_dir)

    def save_maze_json(self, filename: str, grid, interactive_mgr=None) -> bool:
        """
        Salva a estrutura completa do labirinto em um arquivo .json.
        """
        if not filename.endswith(".json"):
            filename += ".json"

        filepath = os.path.join(self.default_dir, filename)

        try:
            maze_data = {
                "metadata": {
                    "team": "inc.gulosinhos_games",
                    "rows": grid.rows,
                    "cols": grid.cols
                },
                "grid": [],
                "elements": {
                    "start": None,
                    "ends": [],
                    "waypoints": [],
                    "keys_and_doors": [],
                    "portals": []
                }
            }

            # Serialização da matriz de células
            for r in range(grid.rows):
                row_data = []
                for c in range(grid.cols):
                    cell = grid.get_cell(r, c)
                    cell_info = {
                        "row": r,
                        "col": c,
                        "type": cell.type,
                        "is_wall": cell.is_wall
                    }
                    row_data.append(cell_info)

                    # Registro de posições especiais
                    if cell.is_start:
                        maze_data["elements"]["start"] = [r, c]
                    elif cell.is_end:
                        maze_data["elements"]["ends"].append([r, c])
                    elif cell.type == config.TYPE_WAYPOINT:
                        maze_data["elements"]["waypoints"].append({
                            "coords": [r, c],
                            "order": getattr(cell, 'waypoint_order', 1)
                        })
                    elif cell.type == config.TYPE_KEY:
                        maze_data["elements"]["keys_and_doors"].append({
                            "type": "KEY",
                            "coords": [r, c],
                            "id": getattr(cell, 'key_id', 1)
                        })
                    elif cell.type == config.TYPE_DOOR:
                        maze_data["elements"]["keys_and_doors"].append({
                            "type": "DOOR",
                            "coords": [r, c],
                            "id": getattr(cell, 'door_id', 1)
                        })

                maze_data["grid"].append(row_data)

            # Exporta portais registrados no InteractiveManager
            if interactive_mgr and hasattr(interactive_mgr, "portals"):
                for c1, c2 in interactive_mgr.portals.items():
                    if c2:
                        maze_data["elements"]["portals"].append({
                            "portal_a": [c1.row, c1.col],
                            "portal_b": [c2.row, c2.col]
                        })

            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(maze_data, f, indent=4)

            return True

        except Exception as e:
            print(f"[FileManager Error] Falha ao salvar arquivo JSON: {e}")
            return False

    def load_maze_json(self, filename: str, grid, interactive_mgr=None) -> bool:
        """
        Carrega a estrutura de um labirinto a partir de um arquivo .json.
        """
        if not filename.endswith(".json"):
            filename += ".json"

        filepath = os.path.join(self.default_dir, filename)

        if not os.path.exists(filepath):
            print(f"[FileManager Error] Arquivo não encontrado: {filepath}")
            return False

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                maze_data = json.load(f)

            rows = maze_data["metadata"]["rows"]
            cols = maze_data["metadata"]["cols"]

            # Redimensiona e limpa a grade atual
            grid.resize(rows, cols)
            grid.clear()
            if interactive_mgr:
                interactive_mgr.clear()

            # Reconstrução das células
            for r_idx, row in enumerate(maze_data["grid"]):
                for c_idx, cell_data in enumerate(row):
                    cell = grid.get_cell(r_idx, c_idx)
                    if cell:
                        if cell_data.get("is_wall", False):
                            cell.make_wall()
                        else:
                            cell.make_empty()

            # Restaura posições especiais
            elems = maze_data.get("elements", {})
            
            if elems.get("start"):
                sr, sc = elems["start"]
                grid.set_start_cell(sr, sc)

            for end_pos in elems.get("ends", []):
                er, ec = end_pos
                grid.add_end_cell(er, ec)

            for wp in elems.get("waypoints", []):
                wr, wc = wp["coords"]
                order = wp.get("order", 1)
                cell = grid.get_cell(wr, wc)
                if cell and interactive_mgr:
                    interactive_mgr.add_waypoint(cell, order)

            for kd in elems.get("keys_and_doors", []):
                kdr, kdc = kd["coords"]
                cell = grid.get_cell(kdr, kdc)
                if cell and interactive_mgr:
                    if kd.get("type") == "KEY":
                        interactive_mgr.add_key(cell, kd.get("id", 1))
                    elif kd.get("type") == "DOOR":
                        interactive_mgr.add_door(cell, kd.get("id", 1))

            return True

        except Exception as e:
            print(f"[FileManager Error] Falha ao carregar arquivo JSON: {e}")
            return False

    def export_to_txt(self, filename: str, grid) -> bool:
        """
        Exporta o mapa em formato de texto ASCII básico (.txt):
        '#' = Parede, '.' = Caminho, 'S' = Início, 'E' = Fim.
        """
        if not filename.endswith(".txt"):
            filename += ".txt"

        filepath = os.path.join(self.default_dir, filename)

        try:
            lines = []
            for r in range(grid.rows):
                line_chars = []
                for c in range(grid.cols):
                    cell = grid.get_cell(r, c)
                    if cell.is_wall:
                        line_chars.append("#")
                    elif cell.is_start:
                        line_chars.append("S")
                    elif cell.is_end:
                        line_chars.append("E")
                    else:
                        line_chars.append(".")
                lines.append("".join(line_chars))

            with open(filepath, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))

            return True

        except Exception as e:
            print(f"[FileManager Error] Falha ao exportar TXT: {e}")
            return False