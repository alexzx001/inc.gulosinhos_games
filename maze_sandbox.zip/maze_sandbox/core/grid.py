import sys
import os

# Garante acesso à raiz do projeto para importação do config
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import config
from core.cell import Cell


class Grid:
    """
    Gerencia a matriz 2D de células, dimensões da grade, verificação de vizinhos,
    posicionamento de elementos especiais e transformações de coordenadas.
    """

    def __init__(self, rows: int = 30, cols: int = 40):
        self.rows = rows
        self.cols = cols
        self.cell_size = getattr(config, 'CELL_SIZE', 20)
        
        self.start_cell = None
        self.end_cells = []
        
        self.grid = []
        self.interactive_mgr = None
        self.hazard_mgr = None
        
        # Variáveis para garantir que o labirinto fique no meio da tela
        self.render_offset_x = 0
        self.render_offset_y = 0
        self.needs_recentering = True
        
        self._build_grid()

    def _build_grid(self):
        """Constrói a matriz inicial preenchida com células vazias."""
        self.grid = []
        for r in range(self.rows):
            row_list = []
            for c in range(self.cols):
                row_list.append(Cell(r, c))
            self.grid.append(row_list)

    def fill_walls(self):
        """Preenche toda a grade com paredes, preservando início e fim."""
        for row in self.grid:
            for cell in row:
                if cell != self.start_cell and cell not in self.end_cells:
                    cell.make_wall()

    def fill_empty(self, interactive_mgr=None):
        """Esvazia toda a grade, limpando paredes, caminhos e elementos interativos."""
        for row in self.grid:
            for cell in row:
                if cell != self.start_cell and cell not in self.end_cells:
                    cell.make_empty()
        mgr = interactive_mgr or self.interactive_mgr
        if mgr and hasattr(mgr, 'clear'):
            mgr.clear()
        if self.hazard_mgr and hasattr(self.hazard_mgr, 'clear'):
            self.hazard_mgr.clear()
        self.reset_pathfinding_states()

    def resize(self, new_rows: int, new_cols: int):
        """Redimensiona a grade mantendo os limites válidos e recentraliza."""
        self.rows = max(5, min(200, int(new_rows)))
        self.cols = max(5, min(200, int(new_cols)))
        self.clear()
        
        # Define posições padrão seguras para início e fim após redimensionar
        self.set_start_cell(1, 1)
        self.add_end_cell(self.rows - 2, self.cols - 2)
        
        self.needs_recentering = True

    def clear(self):
        """Reseta toda a grade para o estado vazio e limpa interativos e perigos."""
        self.start_cell = None
        self.end_cells.clear()
        if self.interactive_mgr and hasattr(self.interactive_mgr, 'clear'):
            self.interactive_mgr.clear()
        if self.hazard_mgr and hasattr(self.hazard_mgr, 'clear'):
            self.hazard_mgr.clear()
        self._build_grid()

    def reset_pathfinding_states(self):
        """Limpa dados de buscas anteriores mantendo paredes e elementos intactos."""
        for row in self.grid:
            for cell in row:
                cell.reset_pathfinding()

    def reset_pathfinding(self):
        """Redireciona para reset_pathfinding_states."""
        self.reset_pathfinding_states()

    def get_cell(self, row: int, col: int) -> Cell:
        """Retorna a célula na posição (row, col) se for válida; caso contrário, None."""
        if 0 <= row < self.rows and 0 <= col < self.cols:
            return self.grid[row][col]
        return None

    def get_cell_at_world_pos(self, world_x: float, world_y: float) -> Cell:
        """Converte coordenadas do mundo (aplicando o offset de centralização) em célula."""
        adjusted_x = world_x - self.render_offset_x
        adjusted_y = world_y - self.render_offset_y
        
        col = int(adjusted_x // self.cell_size)
        row = int(adjusted_y // self.cell_size)
        return self.get_cell(row, col)

    def set_start_cell(self, row: int, col: int):
        """Define uma nova célula inicial, removendo a anterior."""
        cell = self.get_cell(row, col)
        if not cell:
            return

        if self.start_cell:
            self.start_cell.make_empty()

        if cell in self.end_cells:
            self.end_cells.remove(cell)

        cell.make_start()
        self.start_cell = cell

    def add_end_cell(self, row: int, col: int):
        """Adiciona uma nova saída ao mapa."""
        cell = self.get_cell(row, col)
        if not cell:
            return

        if cell == self.start_cell:
            self.start_cell = None

        cell.make_end()
        if cell not in self.end_cells:
            self.end_cells.append(cell)

    def remove_end_cell(self, cell: Cell):
        """Remove uma saída específica da lista de objetivos."""
        if cell in self.end_cells:
            self.end_cells.remove(cell)
            cell.make_empty()

    def get_neighbors(self, cell: Cell, allow_diagonals: bool = False) -> list:
        """Retorna os vizinhos ortogonais (e diagonais se ativado) válidos de uma célula."""
        neighbors = []
        r, c = cell.row, cell.col

        directions = [(-1, 0), (0, 1), (1, 0), (0, -1)]
        
        if allow_diagonals:
            directions.extend([(-1, -1), (-1, 1), (1, 1), (1, -1)])

        for dr, dc in directions:
            neighbor = self.get_cell(r + dr, c + dc)
            if neighbor and not neighbor.is_wall:
                neighbors.append(neighbor)

        return neighbors

    def apply_tool(self, cell: Cell, tool_name: str, interactive_mgr=None, hazard_mgr=None, pair_id=None):
        """Aplica a ferramenta de edição selecionada sobre a célula especificada."""
        if not cell:
            return

        mgr = interactive_mgr or self.interactive_mgr
        h_mgr = hazard_mgr or self.hazard_mgr

        if tool_name == "WALL":
            if cell == self.start_cell:
                self.start_cell = None
            if cell in self.end_cells:
                self.end_cells.remove(cell)
            if mgr:
                mgr.remove_element_at(cell)
            if h_mgr and hasattr(h_mgr, 'remove_hazard_at'):
                h_mgr.remove_hazard_at(cell)
            cell.make_wall()

        elif tool_name in ("ERASER", "EMPTY"):
            if cell == self.start_cell:
                self.start_cell = None
            if cell in self.end_cells:
                self.end_cells.remove(cell)
            if mgr:
                mgr.remove_element_at(cell)
            if h_mgr and hasattr(h_mgr, 'remove_hazard_at'):
                h_mgr.remove_hazard_at(cell)
            cell.make_empty()

        elif tool_name == "START":
            if mgr:
                mgr.remove_element_at(cell)
            if h_mgr and hasattr(h_mgr, 'remove_hazard_at'):
                h_mgr.remove_hazard_at(cell)
            self.set_start_cell(cell.row, cell.col)

        elif tool_name in ("END", "EXIT"):
            if mgr:
                mgr.remove_element_at(cell)
            if h_mgr and hasattr(h_mgr, 'remove_hazard_at'):
                h_mgr.remove_hazard_at(cell)
            self.add_end_cell(cell.row, cell.col)

        elif tool_name == "WAYPOINT" and mgr:
            if cell == self.start_cell:
                self.start_cell = None
            if cell in self.end_cells:
                self.end_cells.remove(cell)
            mgr.add_waypoint(cell)

        elif tool_name == "KEY" and mgr:
            if cell == self.start_cell:
                self.start_cell = None
            if cell in self.end_cells:
                self.end_cells.remove(cell)
            p_id = pair_id if pair_id is not None else getattr(mgr, 'current_pair_id', 1)
            mgr.add_key(cell, p_id)

        elif tool_name == "DOOR" and mgr:
            if cell == self.start_cell:
                self.start_cell = None
            if cell in self.end_cells:
                self.end_cells.remove(cell)
            p_id = pair_id if pair_id is not None else getattr(mgr, 'current_pair_id', 1)
            mgr.add_door(cell, p_id)

        elif tool_name == "PORTAL" and mgr:
            if cell == self.start_cell:
                self.start_cell = None
            if cell in self.end_cells:
                self.end_cells.remove(cell)
            mgr.add_portal(cell)

    def load_from_real_map(self, nodes: dict, edges: list) -> bool:
        """
        Carrega a malha de ruas reais convertendo nós (lat/lon) e arestas para a grade.
        Usa Bresenham com conectividade 4-way para garantir caminhos navegáveis por A*/Dijkstra
        e posiciona automaticamente Início e Fim em extremidades opostas conectadas.
        """
        if not nodes:
            return False

        # 1. Limpa o mapa atual e elementos interativos
        self.clear()
        if self.interactive_mgr and hasattr(self.interactive_mgr, 'clear'):
            self.interactive_mgr.clear()
        if self.hazard_mgr and hasattr(self.hazard_mgr, 'clear'):
            self.hazard_mgr.clear()

        # 2. Preenche toda a grade com paredes
        self.fill_walls()

        # 3. Normaliza coordenadas geográficas
        lats = [coord[0] for coord in nodes.values()]
        lons = [coord[1] for coord in nodes.values()]
        min_lat, max_lat = min(lats), max(lats)
        min_lon, max_lon = min(lons), max(lons)

        lat_span = max_lat - min_lat
        lon_span = max_lon - min_lon
        if lat_span <= 1e-9: lat_span = 1e-6
        if lon_span <= 1e-9: lon_span = 1e-6

        margin = 2
        usable_rows = max(1, self.rows - 2 * margin - 1)
        usable_cols = max(1, self.cols - 2 * margin - 1)

        def to_grid(lat, lon):
            norm_y = (max_lat - lat) / lat_span  # Norte no topo (menor linha)
            norm_x = (lon - min_lon) / lon_span  # Oeste na esquerda (menor coluna)
            r = int(margin + norm_y * usable_rows)
            c = int(margin + norm_x * usable_cols)
            r = max(1, min(self.rows - 2, r))
            c = max(1, min(self.cols - 2, c))
            return r, c

        street_cells = set()

        def bresenham_4way(r0, c0, r1, c1):
            pts = []
            dr = abs(r1 - r0)
            dc = abs(c1 - c0)
            sr = 1 if r0 < r1 else -1
            sc = 1 if c0 < c1 else -1
            err = dc - dr
            cr, cc = r0, c0
            while True:
                pts.append((cr, cc))
                if cr == r1 and cc == c1:
                    break
                e2 = 2 * err
                step_r = False
                step_c = False
                if e2 > -dr:
                    err -= dr
                    cc += sc
                    step_c = True
                if e2 < dc:
                    err += dc
                    cr += sr
                    step_r = True
                if step_r and step_c:
                    pts.append((cr, cc - sc))
            return pts

        # Desenha as arestas das ruas
        for u, v in edges:
            if u in nodes and v in nodes:
                r0, c0 = to_grid(*nodes[u])
                r1, c1 = to_grid(*nodes[v])
                for r, c in bresenham_4way(r0, c0, r1, c1):
                    cell = self.get_cell(r, c)
                    if cell:
                        cell.make_empty()
                        street_cells.add(cell)

        # Se não houver arestas desenhadas, esvazia ao menos os nós
        if not street_cells:
            for node_id, (lat, lon) in nodes.items():
                r, c = to_grid(lat, lon)
                cell = self.get_cell(r, c)
                if cell:
                    cell.make_empty()
                    street_cells.add(cell)

        if not street_cells:
            self.set_start_cell(1, 1)
            self.add_end_cell(self.rows - 2, self.cols - 2)
            return True

        # 4. Encontra componentes conexas para garantir rota viável
        visited = set()
        components = []
        for cell in street_cells:
            if cell not in visited:
                comp = []
                queue = [cell]
                visited.add(cell)
                while queue:
                    curr = queue.pop(0)
                    comp.append(curr)
                    for neighbor in self.get_neighbors(curr):
                        if not neighbor.is_wall and neighbor in street_cells and neighbor not in visited:
                            visited.add(neighbor)
                            queue.append(neighbor)
                components.append(comp)

        largest_comp = max(components, key=len) if components else list(street_cells)

        # Início na extremidade mais próxima do canto superior esquerdo
        start_node = min(largest_comp, key=lambda c: (c.row - margin)**2 + (c.col - margin)**2)

        # BFS para encontrar o ponto mais distante dentro da mesma malha conectada
        dist = {start_node: 0}
        q = [start_node]
        furthest_node = start_node
        max_dist = 0
        while q:
            curr = q.pop(0)
            curr_d = dist[curr]
            if curr_d > max_dist:
                max_dist = curr_d
                furthest_node = curr
            for neighbor in self.get_neighbors(curr):
                if not neighbor.is_wall and neighbor not in dist:
                    dist[neighbor] = curr_d + 1
                    q.append(neighbor)

        # Garante que início e fim sejam células distintas
        if furthest_node == start_node:
            for cell in largest_comp:
                if cell != start_node:
                    furthest_node = cell
                    break
            else:
                next_c = min(self.cols - 2, start_node.col + 1)
                adj = self.get_cell(start_node.row, next_c)
                if adj:
                    adj.make_empty()
                    furthest_node = adj

        self.set_start_cell(start_node.row, start_node.col)
        self.add_end_cell(furthest_node.row, furthest_node.col)
        self.reset_pathfinding_states()
        return True
