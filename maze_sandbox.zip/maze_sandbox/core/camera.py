import sys
import os
import math

# Garante acesso à raiz do projeto para importação do config
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import config


class Camera:
    """
    Controla a projeção do mundo na tela (Viewport), suportando:
    1. Modo 2D Clássico (Top-Down com Pan e Zoom)
    2. Modo 3D Orbital (Visão Panorâmica 360°, Inclinação/Pitch e Zoom Dinâmico)
    3. Modo Primeira Pessoa (Navegação Célula a Célula em 3D)
    """

    MODE_2D = "2D"
    MODE_3D_ORBIT = "3D_ORBIT"
    MODE_FIRST_PERSON = "FIRST_PERSON"

    DIR_OFFSETS = [(-1, 0), (0, 1), (1, 0), (0, -1)]  # 0: Norte, 1: Leste, 2: Sul, 3: Oeste
    DIR_NAMES = ["Norte", "Leste", "Sul", "Oeste"]

    def __init__(self, viewport_width: int, viewport_height: int):
        self.viewport_width = viewport_width
        self.viewport_height = viewport_height

        # Modo atual de visualização
        self.mode = self.MODE_2D

        # --- CONTROLE MODO 2D ---
        self.offset_x = 0.0
        self.offset_y = 0.0
        self.zoom_level = 1.0
        self.min_zoom = 0.2
        self.max_zoom = 5.0

        # --- CONTROLE MODO 3D ORBITAL ---
        self.yaw = 0.785   # Rotação horizontal (45 graus inicial)
        self.pitch = 0.65  # Inclinação vertical (aprox 37 graus)
        self.orbit_zoom = 1.0
        self.pan_3d_x = 0.0
        self.pan_3d_y = 0.0

        # --- CONTROLE MODO PRIMEIRA PESSOA (GRID-BASED) ---
        self.player_row = 1
        self.player_col = 1
        self.player_dir = 1  # Leste inicial
        self.player_collected_keys = set()
        self.last_move_message = ""

    def set_player_pos(self, row: int, col: int, direction: int = None):
        """Define a posição do jogador no grid em modo primeira pessoa."""
        self.player_row = row
        self.player_col = col
        if direction is not None:
            self.player_dir = direction
        self.player_collected_keys.clear()
        self.last_move_message = ""

    def update_viewport(self, width: int, height: int):
        """Atualiza as dimensões da área de exibição quando a janela é redimensionada."""
        self.viewport_width = width
        self.viewport_height = height

    def handle_resize(self, width: int, height: int):
        """Alias para atualização de viewport para manter compatibilidade com o main."""
        self.update_viewport(width, height)

    def set_mode(self, new_mode: str):
        """Altera o modo de visualização entre 2D, 3D_ORBIT e FIRST_PERSON."""
        if new_mode in (self.MODE_2D, self.MODE_3D_ORBIT, self.MODE_FIRST_PERSON):
            self.mode = new_mode

    # ==========================================
    # --- MÉTODOS MODO 2D (COMPATIBILIDADE) ----
    # ==========================================
    def world_to_screen(self, world_x: float, world_y: float) -> tuple:
        """Converte coordenadas do mundo 2D para coordenadas da tela."""
        screen_x = int((world_x - self.offset_x) * self.zoom_level)
        screen_y = int((world_y - self.offset_y) * self.zoom_level)
        return screen_x, screen_y

    def screen_to_world(self, screen_x: float, screen_y: float) -> tuple:
        """Converte coordenadas da tela para coordenadas do mundo 2D."""
        world_x = (screen_x / self.zoom_level) + self.offset_x
        world_y = (screen_y / self.zoom_level) + self.offset_y
        return world_x, world_y

    def pan(self, dx: float, dy: float):
        """Desloca a posição da câmera 2D pelo mapa."""
        self.offset_x -= dx / self.zoom_level
        self.offset_y -= dy / self.zoom_level

    def zoom_in(self, focus_screen_pos: tuple = None, factor: float = 1.1):
        self._apply_zoom(factor, focus_screen_pos)

    def zoom_out(self, focus_screen_pos: tuple = None, factor: float = 1.1):
        self._apply_zoom(1.0 / factor, focus_screen_pos)

    def zoom(self, scroll_direction: int, mouse_x: int, mouse_y: int):
        """Interface para zoom via scroll do mouse."""
        if self.mode == self.MODE_3D_ORBIT:
            factor = 1.15 if scroll_direction > 0 else 1.0 / 1.15
            self.zoom_orbit(factor)
        else:
            if scroll_direction > 0:
                self.zoom_in((mouse_x, mouse_y))
            elif scroll_direction < 0:
                self.zoom_out((mouse_x, mouse_y))

    def _apply_zoom(self, zoom_factor: float, focus_screen_pos: tuple = None):
        if focus_screen_pos is None:
            focus_screen_pos = (self.viewport_width // 2, self.viewport_height // 2)

        screen_x, screen_y = focus_screen_pos
        world_x_before, world_y_before = self.screen_to_world(screen_x, screen_y)

        new_zoom = max(self.min_zoom, min(self.max_zoom, self.zoom_level * zoom_factor))
        if new_zoom == self.zoom_level:
            return

        self.zoom_level = new_zoom
        world_x_after, world_y_after = self.screen_to_world(screen_x, screen_y)
        self.offset_x += (world_x_before - world_x_after)
        self.offset_y += (world_y_before - world_y_after)

    # ==========================================
    # --- MÉTODOS MODO 3D ORBITAL --------------
    # ==========================================
    def rotate_orbit(self, dyaw: float, dpitch: float):
        """Rotaciona a câmera orbital 3D em 360° no yaw e limita o pitch vertical."""
        self.yaw = (self.yaw + dyaw) % (2 * math.pi)
        self.pitch = max(0.18, min(1.48, self.pitch + dpitch))

    def pan_orbit(self, dx: float, dy: float):
        """Move o centro da visão 3D pela tela."""
        self.pan_3d_x += dx
        self.pan_3d_y += dy

    def zoom_orbit(self, factor: float):
        """Aumenta ou diminui o zoom da visão 3D."""
        self.orbit_zoom = max(0.2, min(5.0, self.orbit_zoom * factor))

    def project_3d_point(self, wx: float, wy: float, wz: float, center_wx: float, center_wy: float) -> tuple:
        """
        Projeta um ponto 3D (wx, wy, wz) do mundo para a tela usando yaw e pitch
        em torno do ponto central da grade. Retorna (screen_x, screen_y, depth).
        """
        rx = wx - center_wx
        ry = wy - center_wy
        rz = wz

        cos_y = math.cos(self.yaw)
        sin_y = math.sin(self.yaw)
        x1 = rx * cos_y - ry * sin_y
        y1 = rx * sin_y + ry * cos_y

        cos_p = math.cos(self.pitch)
        sin_p = math.sin(self.pitch)
        y2 = y1 * sin_p - rz * cos_p
        depth = y1 * cos_p + rz * sin_p

        scale = self.orbit_zoom
        center_x = (self.viewport_width / 2) + self.pan_3d_x
        center_y = (self.viewport_height / 2) + self.pan_3d_y

        screen_x = int(center_x + x1 * scale)
        screen_y = int(center_y + y2 * scale)
        return screen_x, screen_y, depth

    # ==========================================
    # --- MÉTODOS MODO PRIMEIRA PESSOA ---------
    # ==========================================
    def set_player_pos(self, row: int, col: int):
        self.player_row = row
        self.player_col = col

    def turn_left(self):
        self.player_dir = (self.player_dir - 1) % 4

    def turn_right(self):
        self.player_dir = (self.player_dir + 1) % 4

    def move_forward(self, grid, interactive_mgr=None) -> bool:
        dr, dc = self.DIR_OFFSETS[self.player_dir]
        return self._try_move_to(self.player_row + dr, self.player_col + dc, grid, interactive_mgr)

    def move_backward(self, grid, interactive_mgr=None) -> bool:
        dr, dc = self.DIR_OFFSETS[self.player_dir]
        return self._try_move_to(self.player_row - dr, self.player_col - dc, grid, interactive_mgr)

    def _try_move_to(self, nr: int, nc: int, grid, interactive_mgr=None) -> bool:
        cell = grid.get_cell(nr, nc)
        if not cell or cell.is_wall:
            self.last_move_message = "Parede bloqueia o caminho!"
            return False

        # Verifica porta trancada
        if cell.type == getattr(config, 'TYPE_DOOR', 6):
            pair_id = getattr(cell, 'door_id', 1) or 1
            if pair_id not in self.player_collected_keys:
                self.last_move_message = f"Porta {pair_id} trancada! Precisa da Chave {pair_id}."
                return False
            else:
                self.last_move_message = f"Porta {pair_id} destrancada!"

        self.player_row = nr
        self.player_col = nc

        # Coleta de chave
        if cell.type == getattr(config, 'TYPE_KEY', 5):
            pair_id = getattr(cell, 'key_id', 1) or 1
            if pair_id not in self.player_collected_keys:
                self.player_collected_keys.add(pair_id)
                self.last_move_message = f"Chave {pair_id} coletada!"

        # Chegada na saída ou waypoint
        if cell.is_end:
            self.last_move_message = "Parabéns! Você alcançou a Saída!"
        elif cell.type == getattr(config, 'TYPE_WAYPOINT', 4):
            self.last_move_message = f"Waypoint {getattr(cell, 'waypoint_order', 1)} atingido!"

        return True