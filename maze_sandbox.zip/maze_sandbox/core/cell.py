import sys
import os

# Garante acesso à raiz do projeto para importação do config
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import config


class Cell:
    """
    Representa uma única célula/nodo da grade do labirinto,
    armazenando seu tipo, custos de busca e estado visual.
    """

    def __init__(self, row: int, col: int):
        self.row = row
        self.col = col

        # Define tipo inicial
        self.type = getattr(config, 'TYPE_EMPTY', 0)

        # Propriedades de Pathfinding (A*, Dijkstra, BFS, DFS)
        self.g_cost = float('inf')
        self.h_cost = 0.0
        self.f_cost = float('inf')
        self.parent = None
        self.visited = False
        self.is_open = False
        self.is_path = False

        # Atributos adicionais para elementos interativos
        self.waypoint_order = None
        self.portal_target = None
        self.door_id = None
        self.key_id = None

    # --- Métodos de Comparação para o heapq (A* / Dijkstra) ---

    def __lt__(self, other):
        """Permite comparar células no heapq quando os custos f_cost forem iguais."""
        if isinstance(other, Cell):
            return (self.row, self.col) < (other.row, other.col)
        return False

    @property
    def is_wall(self) -> bool:
        return self.type == getattr(config, 'TYPE_WALL', 1)

    @property
    def is_start(self) -> bool:
        return self.type == getattr(config, 'TYPE_START', 2)

    @property
    def is_end(self) -> bool:
        return self.type == getattr(config, 'TYPE_END', 3)

    def reset_pathfinding(self):
        """Reseta os custos e estados de algoritmos de busca."""
        self.g_cost = float('inf')
        self.h_cost = 0.0
        self.f_cost = float('inf')
        self.parent = None
        self.visited = False
        self.is_open = False
        self.is_path = False

    def reset_element_metadata(self):
        """Limpa dados associados a objetos interativos."""
        self.waypoint_order = None
        self.portal_target = None
        self.door_id = None
        self.key_id = None

    # --- Alteradores de Estado/Tipo da Célula ---

    def make_empty(self):
        self.type = getattr(config, 'TYPE_EMPTY', 0)
        self.reset_element_metadata()

    def make_wall(self):
        self.type = getattr(config, 'TYPE_WALL', 1)
        self.reset_element_metadata()

    def make_start(self):
        self.type = getattr(config, 'TYPE_START', 2)
        self.reset_element_metadata()

    def make_end(self):
        self.type = getattr(config, 'TYPE_END', 3)
        self.reset_element_metadata()

    def make_waypoint(self, order: int = 1):
        self.type = getattr(config, 'TYPE_WAYPOINT', 4)
        self.waypoint_order = order

    def make_key(self, key_id: int = 1):
        self.type = getattr(config, 'TYPE_KEY', 5)
        self.key_id = key_id

    def make_door(self, door_id: int = 1):
        self.type = getattr(config, 'TYPE_DOOR', 6)
        self.door_id = door_id

    def make_portal(self, target_cell=None):
        self.type = getattr(config, 'TYPE_PORTAL', 7)
        self.portal_target = target_cell

    def make_hazard(self):
        self.type = getattr(config, 'TYPE_HAZARD', 8)