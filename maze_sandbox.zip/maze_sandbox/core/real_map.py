"""
core/real_map.py — Módulo de Renderização Cartográfica e Navegação Real (Estilo Google Maps / Waze).
Renderiza a malha viária vetorial contínua com nomes de ruas, hierarquia visual de pistas,
cruzamentos suaves, buscador de rotas animado (A* / Dijkstra) e Simulação de Navegação GPS
com veículo em tempo real, instruções de conversão (turn-by-turn) e tempo estimado de trajeto.
100% nativo em Python e Pygame, sem APIs pagas e sem dependências externas.
"""
import math
import heapq
import pygame
from utils.map_loader import haversine_distance


class RealMapGraph:
    """
    Gerenciador da malha viária vetorial estilo Google Maps / Waze.
    Suporta:
      - Traçado cartográfico com pistas, contornos e junções contínuas
      - Exibição de nomes de ruas nas vias com orientação angular
      - Busca geodésica com Buscador animado (A* e Dijkstra)
      - Simulação de navegação GPS com carrinho/seta e banner passo-a-passo
    """

    def __init__(self):
        self.nodes = {}      # {node_id: (lat, lon)}
        self.edges = []      # [(u, v, dist_m, hw_type, street_name)]
        self.adj = {}        # {u: [(v, dist_m, hw_type, name), ...]}

        self.location_name = ""
        self.center_lat = 0.0
        self.center_lon = 0.0
        self.min_lat = 0.0
        self.max_lat = 0.0
        self.min_lon = 0.0
        self.max_lon = 0.0

        # Câmera e Viewport Vetorial
        self.scale = 100000.0   # Pixels por grau geográfico
        self.pan_x = 0.0
        self.pan_y = 0.0
        self.min_scale = 8000.0
        self.max_scale = 3000000.0

        # Seleção de Início (A - Partida) e Fim (B - Destino)
        self.start_node = None
        self.end_node = None
        self.hovered_node = None

        # Algoritmo de Busca de Rota
        self.algorithm = "A*"
        self.is_running = False
        self.is_finished = False
        self.open_set = []          # heap de [(f_score, node_id)]
        self.g_score = {}           # {node_id: dist_m}
        self.came_from = {}         # {node_id: parent_node_id}
        self.visited_nodes = set()
        self.explored_edges = set() # set de (min_uv, max_uv)
        self.final_path = []        # [node_id, ...]
        self.total_path_distance = 0.0
        self.current_seeker_node = None
        self.search_status_msg = "Pronto para navegar"

        # Simulação de Navegação GPS (Estilo Waze / Google Maps)
        self.simulating_navigation = False
        self.nav_progress = 0.0     # Índice float ao longo de final_path
        self.nav_speed = 0.8        # Nós por segundo (ajustável)
        self.show_street_names = True

        # Fontes do mapa
        self.font_banner_title = pygame.font.SysFont("Segoe UI", 13, bold=True)
        self.font_banner_sub = pygame.font.SysFont("Segoe UI", 11)
        self.font_street = pygame.font.SysFont("Segoe UI", 9, bold=True)
        self.font_small = pygame.font.SysFont("Segoe UI", 10)
        self.font_hud = pygame.font.SysFont("Segoe UI", 11, bold=True)
        self.font_node = pygame.font.SysFont("Segoe UI", 10, bold=True)

    def load_graph(self, nodes: dict, edges: list, location_name: str = "", center_lat: float = None, center_lon: float = None):
        """Carrega os dados da malha viária e enquadra perfeitamente na tela."""
        self.nodes = nodes
        self.edges = edges
        self.location_name = location_name

        # Constrói adjacências com metadados de vias e nomes de ruas
        self.adj = {nid: [] for nid in self.nodes}
        for item in self.edges:
            u, v, dist = item[0], item[1], item[2]
            hw_type = item[3] if len(item) > 3 else "residential"
            name = item[4] if len(item) > 4 else ""
            if u in self.adj and v in self.nodes:
                self.adj[u].append((v, dist, hw_type, name))

        if not self.nodes:
            return

        lats = [coord[0] for coord in self.nodes.values()]
        lons = [coord[1] for coord in self.nodes.values()]
        self.min_lat, self.max_lat = min(lats), max(lats)
        self.min_lon, self.max_lon = min(lons), max(lons)

        self.center_lat = center_lat if center_lat is not None else (self.min_lat + self.max_lat) / 2.0
        self.center_lon = center_lon if center_lon is not None else (self.min_lon + self.max_lon) / 2.0

        # Reseta Pan e calcula enquadramento ideal
        self.pan_x = 0.0
        self.pan_y = 0.0
        lat_span = max(1e-5, self.max_lat - self.min_lat)
        lon_span = max(1e-5, self.max_lon - self.min_lon)
        self.scale = min(620.0 / lat_span, 820.0 / lon_span) * 0.85
        self.scale = max(self.min_scale, min(self.max_scale, self.scale))

        # Seleciona automaticamente Início e Fim na maior malha viária
        self._auto_select_start_end()
        self.reset_pathfinding()
        self.search_status_msg = f"Mapa de '{location_name or 'OSM'}' carregado!"

    def _auto_select_start_end(self):
        """Identifica a maior componente de ruas e escolhe as duas extremidades como Início e Fim."""
        if not self.nodes or not self.adj:
            self.start_node = None
            self.end_node = None
            return

        visited = set()
        components = []
        for nid in self.nodes:
            if nid not in visited and self.adj.get(nid):
                comp = []
                queue = [nid]
                visited.add(nid)
                while queue:
                    curr = queue.pop(0)
                    comp.append(curr)
                    for neighbor_info in self.adj.get(curr, []):
                        nbr = neighbor_info[0]
                        if nbr not in visited:
                            visited.add(nbr)
                            queue.append(nbr)
                components.append(comp)

        if not components:
            node_keys = list(self.nodes.keys())
            self.start_node = node_keys[0] if node_keys else None
            self.end_node = node_keys[-1] if len(node_keys) > 1 else None
            return

        largest = max(components, key=len)

        # Escolhe um nó candidato no extremo
        start_candidate = min(largest, key=lambda nid: self.nodes[nid][0] + self.nodes[nid][1])

        # BFS para encontrar o nó mais distante na mesma malha
        dist_map = {start_candidate: 0.0}
        q = [start_candidate]
        furthest = start_candidate
        max_d = 0.0
        while q:
            curr = q.pop(0)
            d = dist_map[curr]
            if d > max_d:
                max_d = d
                furthest = curr
            for neighbor_info in self.adj.get(curr, []):
                nbr, edge_d = neighbor_info[0], neighbor_info[1]
                if nbr not in dist_map:
                    dist_map[nbr] = d + edge_d
                    q.append(nbr)

        self.start_node = start_candidate
        self.end_node = furthest if furthest != start_candidate else largest[-1]

    # ------------------------------------------------------------------
    # Projeção Geográfica / Tela
    # ------------------------------------------------------------------
    def coord_to_screen(self, lat: float, lon: float, vp_rect: pygame.Rect) -> tuple:
        """Converte latitude e longitude para coordenadas de pixel da tela."""
        cos_lat = math.cos(math.radians(self.center_lat))
        dx = (lon - self.center_lon) * cos_lat * self.scale
        dy = -(lat - self.center_lat) * self.scale

        sx = int(vp_rect.centerx + self.pan_x + dx)
        sy = int(vp_rect.centery + self.pan_y + dy)
        return sx, sy

    def screen_to_coord(self, sx: int, sy: int, vp_rect: pygame.Rect) -> tuple:
        """Converte pixel da tela para latitude e longitude."""
        cos_lat = math.cos(math.radians(self.center_lat))
        if cos_lat == 0:
            cos_lat = 1e-6
        dx = sx - (vp_rect.centerx + self.pan_x)
        dy = sy - (vp_rect.centery + self.pan_y)

        lon = self.center_lon + (dx / (self.scale * cos_lat))
        lat = self.center_lat - (dy / self.scale)
        return lat, lon

    def pan(self, dx: float, dy: float):
        self.pan_x += dx
        self.pan_y += dy

    def zoom(self, factor: float, mouse_x: int, mouse_y: int, vp_rect: pygame.Rect):
        old_scale = self.scale
        new_scale = max(self.min_scale, min(self.max_scale, self.scale * factor))
        if new_scale == old_scale:
            return

        rel_x = mouse_x - (vp_rect.centerx + self.pan_x)
        rel_y = mouse_y - (vp_rect.centery + self.pan_y)
        ratio = new_scale / old_scale
        self.pan_x -= rel_x * (ratio - 1.0)
        self.pan_y -= rel_y * (ratio - 1.0)
        self.scale = new_scale

    def find_nearest_node(self, mouse_pos: tuple, vp_rect: pygame.Rect, max_dist_px: float = 24.0):
        """Retorna o ID do nó de cruzamento mais próximo do cursor do mouse."""
        if not self.nodes:
            return None
        closest_id = None
        closest_d_sq = max_dist_px * max_dist_px

        mx, my = mouse_pos
        for nid, (lat, lon) in self.nodes.items():
            sx, sy = self.coord_to_screen(lat, lon, vp_rect)
            d_sq = (sx - mx) ** 2 + (sy - my) ** 2
            if d_sq < closest_d_sq:
                closest_d_sq = d_sq
                closest_id = nid
        return closest_id

    # ------------------------------------------------------------------
    # Algoritmos de Busca em Grafo (A* e Dijkstra com Heurística Haversine)
    # ------------------------------------------------------------------
    def set_algorithm(self, algo_name: str):
        self.algorithm = "Dijkstra" if "Dijkstra" in algo_name else "A*"
        self.reset_pathfinding()

    def reset_pathfinding(self):
        self.is_running = False
        self.is_finished = False
        self.simulating_navigation = False
        self.nav_progress = 0.0
        self.open_set.clear()
        self.g_score.clear()
        self.came_from.clear()
        self.visited_nodes.clear()
        self.explored_edges.clear()
        self.final_path.clear()
        self.total_path_distance = 0.0
        self.current_seeker_node = self.start_node
        self.search_status_msg = "Pronto para buscar rota"

    def start_pathfinding(self):
        if not self.start_node or not self.end_node or self.start_node not in self.nodes or self.end_node not in self.nodes:
            self.search_status_msg = "Selecione Início e Destino no mapa!"
            return
        self.reset_pathfinding()
        self.is_running = True
        self.search_status_msg = "Calculando rota no mapa..."

        self.g_score[self.start_node] = 0.0
        h = self._heuristic(self.start_node, self.end_node)
        heapq.heappush(self.open_set, (h, self.start_node))
        self.current_seeker_node = self.start_node

    def _heuristic(self, u_id, v_id) -> float:
        if self.algorithm == "Dijkstra":
            return 0.0
        u_lat, u_lon = self.nodes[u_id]
        v_lat, v_lon = self.nodes[v_id]
        return haversine_distance(u_lat, u_lon, v_lat, v_lon)

    def step_pathfinding(self, max_steps: int = 1) -> bool:
        """Executa passos do algoritmo de busca e atualiza a posição do buscador."""
        if not self.is_running or self.is_finished:
            return False

        for _ in range(max_steps):
            if not self.open_set:
                self.is_running = False
                self.is_finished = True
                self.search_status_msg = "Destino inacessível por esta via!"
                return False

            _, current = heapq.heappop(self.open_set)

            if current in self.visited_nodes:
                continue
            self.visited_nodes.add(current)
            self.current_seeker_node = current

            if current == self.end_node:
                self._reconstruct_path()
                self.is_running = False
                self.is_finished = True
                dist_km = self.total_path_distance / 1000.0
                self.search_status_msg = f"✓ Rota calculada: {self.total_path_distance:.0f}m ({dist_km:.2f}km)"
                return True

            curr_g = self.g_score[current]
            for neighbor_info in self.adj.get(current, []):
                neighbor, weight = neighbor_info[0], neighbor_info[1]
                tentative_g = curr_g + weight
                if tentative_g < self.g_score.get(neighbor, float('inf')):
                    self.g_score[neighbor] = tentative_g
                    self.came_from[neighbor] = current
                    self.explored_edges.add((min(current, neighbor), max(current, neighbor)))
                    f = tentative_g + self._heuristic(neighbor, self.end_node)
                    heapq.heappush(self.open_set, (f, neighbor))

        return True

    def solve_instant(self):
        """Calcula o caminho completo imediatamente."""
        if not self.is_running and not self.is_finished:
            self.start_pathfinding()
        while self.is_running:
            self.step_pathfinding(max_steps=60)

    def _reconstruct_path(self):
        """Reconstrói o trajeto final percorrido pelo algoritmo."""
        self.final_path.clear()
        curr = self.end_node
        self.total_path_distance = self.g_score.get(self.end_node, 0.0)

        while curr is not None:
            self.final_path.append(curr)
            curr = self.came_from.get(curr)
        self.final_path.reverse()

    # ------------------------------------------------------------------
    # Simulação de Navegação GPS (Waze / Google Maps Drive)
    # ------------------------------------------------------------------
    def toggle_navigation(self):
        """Inicia ou pausa a simulação do veículo percorrendo a rota."""
        if len(self.final_path) < 2:
            self.solve_instant()
        if len(self.final_path) < 2:
            return

        if self.simulating_navigation:
            self.simulating_navigation = False
        else:
            if self.nav_progress >= len(self.final_path) - 1:
                self.nav_progress = 0.0
            self.simulating_navigation = True

    def update_navigation(self, delta_time: float):
        """Avança a simulação do veículo ao longo da rota em função do tempo."""
        if not self.simulating_navigation or len(self.final_path) < 2:
            return

        # Avanço do veículo proporcional à velocidade e delta_time
        self.nav_progress += self.nav_speed * (delta_time * 0.1)
        if self.nav_progress >= len(self.final_path) - 1:
            self.nav_progress = float(len(self.final_path) - 1)
            self.simulating_navigation = False

    def toggle_street_names(self):
        self.show_street_names = not self.show_street_names

    def get_current_nav_info(self, vp_rect: pygame.Rect):
        """Calcula a posição atual do veículo, rua atual, próxima conversão e distância restante."""
        if len(self.final_path) < 2:
            return None

        p = max(0.0, min(float(len(self.final_path) - 1), self.nav_progress))
        idx = int(p)
        frac = p - idx

        u_id = self.final_path[idx]
        v_id = self.final_path[min(idx + 1, len(self.final_path) - 1)]

        u_lat, u_lon = self.nodes[u_id]
        v_lat, v_lon = self.nodes[v_id]

        curr_lat = u_lat + (v_lat - u_lat) * frac
        curr_lon = u_lon + (v_lon - u_lon) * frac
        veh_pt = self.coord_to_screen(curr_lat, curr_lon, vp_rect)

        # Ângulo do veículo
        p1 = self.coord_to_screen(u_lat, u_lon, vp_rect)
        p2 = self.coord_to_screen(v_lat, v_lon, vp_rect)
        veh_angle = math.degrees(math.atan2(p2[1] - p1[1], p2[0] - p1[0]))

        # Descobre nome da rua atual
        curr_street = "Via Local"
        for item in self.edges:
            edge_u, edge_v = item[0], item[1]
            name = item[4] if len(item) > 4 else ""
            if (edge_u == u_id and edge_v == v_id) or (edge_u == v_id and edge_v == u_id):
                if name:
                    curr_street = name
                    break

        # Próxima conversão
        turn_symbol = "⬆"
        turn_text = "Siga em frente"
        next_street = curr_street
        dist_to_next = haversine_distance(curr_lat, curr_lon, v_lat, v_lon)

        if idx + 2 < len(self.final_path):
            w_id = self.final_path[idx + 2]
            w_lat, w_lon = self.nodes[w_id]
            p3 = self.coord_to_screen(w_lat, w_lon, vp_rect)

            v1 = (p2[0] - p1[0], p2[1] - p1[1])
            v2 = (p3[0] - p2[0], p3[1] - p2[1])
            cross = v1[0] * v2[1] - v1[1] * v2[0]

            for item in self.edges:
                edge_u, edge_v = item[0], item[1]
                name = item[4] if len(item) > 4 else ""
                if (edge_u == v_id and edge_v == w_id) or (edge_u == w_id and edge_v == v_id):
                    if name:
                        next_street = name
                        break

            if cross > 40:
                turn_symbol = "↱"
                turn_text = f"Vire à direita na {next_street}"
            elif cross < -40:
                turn_symbol = "↰"
                turn_text = f"Vire à esquerda na {next_street}"
            else:
                turn_symbol = "⬆"
                turn_text = f"Siga em frente na {next_street}"
        elif frac >= 0.95 or idx >= len(self.final_path) - 1:
            turn_symbol = "🏁"
            turn_text = "Você chegou ao seu destino!"

        # Distância restante até o final
        remaining_dist = dist_to_next
        for i in range(idx + 1, len(self.final_path) - 1):
            n1 = self.nodes[self.final_path[i]]
            n2 = self.nodes[self.final_path[i + 1]]
            remaining_dist += haversine_distance(n1[0], n1[1], n2[0], n2[1])

        return {
            "vehicle_pt": veh_pt,
            "vehicle_angle": veh_angle,
            "curr_street": curr_street,
            "next_street": next_street,
            "turn_symbol": turn_symbol,
            "turn_text": turn_text,
            "dist_to_next": dist_to_next,
            "remaining_dist": remaining_dist
        }

    # ------------------------------------------------------------------
    # Renderização Cartográfica Profissional (Google Maps / Waze Style)
    # ------------------------------------------------------------------
    def draw(self, surface: pygame.Surface, vp_rect: pygame.Rect):
        """Desenha a malha viária, nomes de ruas, rotas, veículo e o banner de navegação GPS."""
        # 1. Fundo do mapa estilo Carto Dark / Waze Night
        pygame.draw.rect(surface, (20, 24, 32), vp_rect)

        if not self.nodes:
            msg = self.font_banner_title.render("Digite um local na barra lateral e clique em 'Carregar Mapa Real'", True, (140, 155, 180))
            surface.blit(msg, msg.get_rect(center=vp_rect.center))
            return

        ticks = pygame.time.get_ticks()

        # 2. Desenha a Base e Contorno das Ruas (Asfalto contínuo e bordas)
        # Passo 2A: Contorno escuro unificado (Casing)
        for item in self.edges:
            u, v = item[0], item[1]
            if u in self.nodes and v in self.nodes:
                p1 = self.coord_to_screen(self.nodes[u][0], self.nodes[u][1], vp_rect)
                p2 = self.coord_to_screen(self.nodes[v][0], self.nodes[v][1], vp_rect)
                hw = item[3] if len(item) > 3 else "residential"
                is_major = hw in ("primary", "trunk", "motorway")
                is_secondary = hw in ("secondary", "tertiary")

                casing_w = 9 if is_major else (7 if is_secondary else 5)
                pygame.draw.line(surface, (12, 15, 20), p1, p2, casing_w)

        # Passo 2B: Pistas de rolamento coloridas por categoria (Google Maps / Waze style)
        for item in self.edges:
            u, v = item[0], item[1]
            if u in self.nodes and v in self.nodes:
                p1 = self.coord_to_screen(self.nodes[u][0], self.nodes[u][1], vp_rect)
                p2 = self.coord_to_screen(self.nodes[v][0], self.nodes[v][1], vp_rect)
                hw = item[3] if len(item) > 3 else "residential"

                if hw in ("primary", "trunk", "motorway"):
                    road_w = 6
                    road_col = (245, 175, 55)    # Dourado / Âmbar vibrante (Avenidas Principais)
                elif hw in ("secondary", "tertiary"):
                    road_w = 4
                    road_col = (205, 215, 230)   # Branco / Cinza claro suave (Vias Coletoras)
                else:
                    road_w = 2.5
                    road_col = (75, 88, 110)     # Cinza asfalto moderno (Ruas Locais)

                pygame.draw.line(surface, road_col, p1, p2, int(road_w))

        # Passo 2C: Junções circulares suaves nos cruzamentos (elimina emendas secas)
        for nid, (lat, lon) in self.nodes.items():
            pt = self.coord_to_screen(lat, lon, vp_rect)
            if vp_rect.collidepoint(pt):
                # Cruzamento mesclado
                pygame.draw.circle(surface, (75, 88, 110), pt, 3)

        # 3. Desenha Vias Exploradas durante a busca (Ciano Elétrico)
        for u, v in self.explored_edges:
            if u in self.nodes and v in self.nodes:
                p1 = self.coord_to_screen(self.nodes[u][0], self.nodes[u][1], vp_rect)
                p2 = self.coord_to_screen(self.nodes[v][0], self.nodes[v][1], vp_rect)
                pygame.draw.line(surface, (0, 200, 255), p1, p2, 4)

        # 4. Rota GPS Final Calculada (Azul Royal e Ciano no estilo Google Maps / Waze)
        if len(self.final_path) >= 2:
            pts = [self.coord_to_screen(self.nodes[nid][0], self.nodes[nid][1], vp_rect) for nid in self.final_path]
            # Borda/Glow azul escuro
            pygame.draw.lines(surface, (15, 60, 160), False, pts, 10)
            # Pista principal azul vibrante (Google Maps Blue)
            pygame.draw.lines(surface, (37, 99, 235), False, pts, 6)
            # Linha de centro luminosa
            pygame.draw.lines(surface, (96, 165, 250), False, pts, 2)

            # Setas chevrons de direção ao longo da rota
            for i in range(len(pts) - 1):
                p_start, p_end = pts[i], pts[i + 1]
                mid_p = ((p_start[0] + p_end[0]) // 2, (p_start[1] + p_end[1]) // 2)
                if vp_rect.collidepoint(mid_p):
                    pygame.draw.circle(surface, (255, 255, 255), mid_p, 3)

        # 5. O Buscador Ativo (Radar pulse durante a busca)
        if self.is_running and self.current_seeker_node and self.current_seeker_node in self.nodes:
            s_lat, s_lon = self.nodes[self.current_seeker_node]
            s_pt = self.coord_to_screen(s_lat, s_lon, vp_rect)
            if vp_rect.collidepoint(s_pt):
                phase = (ticks % 1000) / 1000.0
                r1 = int(8 + phase * 24)
                radar_surf = pygame.Surface((70, 70), pygame.SRCALPHA)
                alpha = max(0, int(220 * (1.0 - phase)))
                pygame.draw.circle(radar_surf, (0, 220, 255, alpha), (35, 35), r1, 2)
                surface.blit(radar_surf, (s_pt[0] - 35, s_pt[1] - 35))
                pygame.draw.circle(surface, (255, 215, 0), s_pt, 6)
                pygame.draw.circle(surface, (255, 255, 255), s_pt, 7, 2)

        # 6. Nomes de Ruas nas Vias (Labels Cartográficos com Orientação)
        if self.show_street_names:
            self._draw_street_names(surface, vp_rect)

        # 7. Marcadores de Partida (A) e Destino (B) - Estilo Pin Google Maps
        self._draw_pins(surface, vp_rect, ticks)

        # 8. Veículo / Cursor de Navegação GPS (Seta Azul estilo Waze/Maps)
        nav_info = self.get_current_nav_info(vp_rect)
        if nav_info and (self.simulating_navigation or len(self.final_path) >= 2):
            self._draw_navigation_vehicle(surface, nav_info, ticks)

        # 9. Destaque de Hover no nó sob o cursor
        if self.hovered_node and self.hovered_node in self.nodes:
            h_lat, h_lon = self.nodes[self.hovered_node]
            h_pt = self.coord_to_screen(h_lat, h_lon, vp_rect)
            pygame.draw.circle(surface, (255, 230, 60), h_pt, 8, 2)
            # Tenta descobrir o nome de uma via que passa aqui
            street_hint = f"Cruzamento #{self.hovered_node}"
            for nbr_info in self.adj.get(self.hovered_node, []):
                name = nbr_info[3] if len(nbr_info) > 3 else ""
                if name:
                    street_hint = f"📍 {name}"
                    break
            tip = self.font_small.render(street_hint, True, (255, 235, 80))
            bg_tip = pygame.Rect(h_pt[0] + 10, h_pt[1] - 12, tip.get_width() + 10, tip.get_height() + 4)
            pygame.draw.rect(surface, (18, 22, 30), bg_tip, border_radius=4)
            pygame.draw.rect(surface, (255, 230, 60), bg_tip, 1, border_radius=4)
            surface.blit(tip, (bg_tip.x + 5, bg_tip.y + 2))

        # 10. Banner Superior de Navegação GPS (Waze / Google Maps Banner)
        self._draw_navigation_banner(surface, vp_rect, nav_info)

        # 11. Barra de Dicas no Rodapé
        hint_text = "Clique Esquerdo: Partida (A)  ·  Clique Direito: Destino (B)  ·  Arrastar: Mover  ·  Scroll: Zoom"
        hint = self.font_small.render(hint_text, True, (130, 145, 170))
        surface.blit(hint, (vp_rect.left + 15, vp_rect.bottom - 22))

    def _draw_street_names(self, surface: pygame.Surface, vp_rect: pygame.Rect):
        """Renderiza nomes de ruas ao longo das vias com espaçamento inteligente para não poluir."""
        drawn_labels = []

        for item in self.edges:
            u, v = item[0], item[1]
            name = item[4] if len(item) > 4 else ""
            if not name or u not in self.nodes or v not in self.nodes:
                continue

            p1 = self.coord_to_screen(self.nodes[u][0], self.nodes[u][1], vp_rect)
            p2 = self.coord_to_screen(self.nodes[v][0], self.nodes[v][1], vp_rect)

            if not vp_rect.collidepoint(p1) and not vp_rect.collidepoint(p2):
                continue

            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]
            seg_len = math.hypot(dx, dy)
            if seg_len < 40:
                continue

            mid_x = (p1[0] + p2[0]) / 2.0
            mid_y = (p1[1] + p2[1]) / 2.0
            if not vp_rect.collidepoint((mid_x, mid_y)):
                continue

            # Evita duplicar rótulos da mesma rua muito próximos
            too_close = False
            for ex, ey, ename in drawn_labels:
                if ename == name and (ex - mid_x) ** 2 + (ey - mid_y) ** 2 < 170 ** 2:
                    too_close = True
                    break
            if too_close:
                continue

            drawn_labels.append((mid_x, mid_y, name))

            # Desenha plaqueta de nome da rua
            lbl = self.font_street.render(name, True, (240, 245, 255))
            bw = lbl.get_width() + 10
            bh = lbl.get_height() + 4

            badge = pygame.Surface((bw, bh), pygame.SRCALPHA)
            badge.fill((22, 28, 38, 225))
            pygame.draw.rect(badge, (50, 65, 85), (0, 0, bw, bh), 1, border_radius=4)
            badge.blit(lbl, (5, 2))

            # Inclinação suave alinhada à pista
            angle_deg = math.degrees(math.atan2(dy, dx))
            if angle_deg > 90:
                angle_deg -= 180
            elif angle_deg < -90:
                angle_deg += 180

            if abs(angle_deg) > 8 and abs(angle_deg) < 82:
                rot = pygame.transform.rotate(badge, -angle_deg)
                surface.blit(rot, rot.get_rect(center=(int(mid_x), int(mid_y))))
            else:
                surface.blit(badge, badge.get_rect(center=(int(mid_x), int(mid_y))))

    def _draw_pins(self, surface: pygame.Surface, vp_rect: pygame.Rect, ticks: int):
        """Desenha os marcadores de Início (A - Partida) e Destino (B - Chegada)."""
        # Marcador A (Origem / Verde)
        if self.start_node and self.start_node in self.nodes:
            s_lat, s_lon = self.nodes[self.start_node]
            pt = self.coord_to_screen(s_lat, s_lon, vp_rect)
            if vp_rect.collidepoint(pt):
                # Sombra
                pygame.draw.circle(surface, (10, 20, 15), (pt[0], pt[1] + 2), 11)
                # Pino Verde
                pygame.draw.circle(surface, (16, 185, 129), pt, 10)
                pygame.draw.circle(surface, (255, 255, 255), pt, 10, 2)
                lbl = self.font_node.render("A", True, (15, 25, 20))
                surface.blit(lbl, lbl.get_rect(center=pt))

        # Marcador B (Destino / Vermelho)
        if self.end_node and self.end_node in self.nodes:
            e_lat, e_lon = self.nodes[self.end_node]
            pt = self.coord_to_screen(e_lat, e_lon, vp_rect)
            if vp_rect.collidepoint(pt):
                # Pulso no destino quando rota encontrada
                if self.is_finished and self.final_path:
                    pulse_r = int(12 + math.sin(ticks * 0.008) * 3)
                    pygame.draw.circle(surface, (239, 68, 68), pt, pulse_r, 2)
                pygame.draw.circle(surface, (25, 10, 10), (pt[0], pt[1] + 2), 11)
                pygame.draw.circle(surface, (239, 68, 68), pt, 10)
                pygame.draw.circle(surface, (255, 255, 255), pt, 10, 2)
                lbl = self.font_node.render("B", True, (255, 255, 255))
                surface.blit(lbl, lbl.get_rect(center=pt))

    def _draw_navigation_vehicle(self, surface: pygame.Surface, nav_info: dict, ticks: int):
        """Desenha a seta/veículo de navegação GPS estilo Google Maps / Waze."""
        veh_pt = nav_info["vehicle_pt"]
        angle = nav_info["vehicle_angle"]

        # Triângulo moderno de navegação (Google Maps Nav Arrow)
        arrow_surf = pygame.Surface((32, 32), pygame.SRCALPHA)
        # Pontos do triângulo voltado para cima (0 deg)
        pts = [(16, 4), (26, 26), (16, 20), (6, 26)]
        pygame.draw.polygon(arrow_surf, (20, 70, 180), pts)
        pygame.draw.polygon(arrow_surf, (37, 99, 235), [(16, 6), (24, 24), (16, 19), (8, 24)])
        pygame.draw.lines(arrow_surf, (255, 255, 255), True, pts, 2)

        # Rotaciona para o ângulo da pista
        rot_surf = pygame.transform.rotate(arrow_surf, -angle - 90)
        surface.blit(rot_surf, rot_surf.get_rect(center=veh_pt))

        # Pulso sutil ao redor do veículo
        if self.simulating_navigation:
            pulse = int(14 + math.sin(ticks * 0.01) * 3)
            pygame.draw.circle(surface, (96, 165, 250), veh_pt, pulse, 1)

    def _draw_navigation_banner(self, surface: pygame.Surface, vp_rect: pygame.Rect, nav_info: dict):
        """Desenha o banner superior com instruções de direção passo a passo (turn-by-turn)."""
        bw = min(500, vp_rect.width - 40)
        bh = 66
        bx = vp_rect.left + 15
        by = vp_rect.top + 15

        banner = pygame.Surface((bw, bh), pygame.SRCALPHA)
        banner.fill((18, 24, 36, 245))
        surface.blit(banner, (bx, by))
        pygame.draw.rect(surface, (37, 99, 235), (bx, by, bw, bh), 1, border_radius=8)

        if nav_info and len(self.final_path) >= 2:
            # Caixa do ícone de conversão (Estilo Waze)
            icon_box = pygame.Rect(bx + 10, by + 11, 44, 44)
            pygame.draw.rect(surface, (37, 99, 235), icon_box, border_radius=6)
            sym = nav_info["turn_symbol"]
            font_icon = pygame.font.SysFont("Segoe UI", 20, bold=True)
            sym_surf = font_icon.render(sym, True, (255, 255, 255))
            surface.blit(sym_surf, sym_surf.get_rect(center=icon_box.center))

            # Instrução Principal
            main_text = nav_info["turn_text"]
            t_surf = self.font_banner_title.render(main_text, True, (245, 250, 255))
            surface.blit(t_surf, (bx + 64, by + 12))

            # Sub-informações: Distância restante e tempo estimado
            rem_m = nav_info["remaining_dist"]
            rem_km = rem_m / 1000.0
            # Tempo estimado a 40 km/h (~11 m/s)
            eta_sec = max(10, int(rem_m / 11.1))
            eta_str = f"{eta_sec // 60} min" if eta_sec >= 60 else f"{eta_sec} seg"

            sub_text = f"Restam {rem_m:.0f}m ({rem_km:.2f} km)  •  ETA: ~{eta_str}  •  Via: {nav_info['curr_street']}"
            s_surf = self.font_banner_sub.render(sub_text, True, (160, 180, 210))
            surface.blit(s_surf, (bx + 64, by + 36))

            # Barra de progresso da rota no rodapé do banner
            if self.simulating_navigation:
                prog_frac = self.nav_progress / max(1, len(self.final_path) - 1)
                bar_w = int((bw - 2) * prog_frac)
                pygame.draw.rect(surface, (16, 185, 129), (bx + 1, by + bh - 4, bar_w, 3), border_radius=2)
        else:
            # Banner informativo quando rota ainda não está calculada
            icon_box = pygame.Rect(bx + 10, by + 11, 44, 44)
            pygame.draw.rect(surface, (44, 55, 75), icon_box, border_radius=6)
            sym_surf = self.font_banner_title.render("🧭", True, (255, 255, 255))
            surface.blit(sym_surf, sym_surf.get_rect(center=icon_box.center))

            title = self.font_banner_title.render(f"🗺 {self.location_name or 'OpenStreetMap'}", True, (0, 205, 245))
            surface.blit(title, (bx + 64, by + 12))

            hint = "Selecione o Início (A) e o Destino (B) no mapa para traçar a rota"
            surface.blit(self.font_banner_sub.render(hint, True, (170, 185, 205)), (bx + 64, by + 36))
