import math
import time
import random as _rnd
import pygame
import config


class Renderer:
    """
    Renderizador do Ultimate Maze Sandbox:
    1. Modo 2D Classico
    2. Modo 3D Orbital (Holograma neon, sem lag)
    3. Modo 1a Pessoa (Raycasting DDA com bussola e indicadores de saida)
    4. Minimapa 2D Flutuante
    """

    def __init__(self, screen: pygame.Surface, camera, grid, ui_manager, real_map=None):
        self.screen = screen
        self.camera = camera
        self.grid = grid
        self.ui_mgr = ui_manager
        self.real_map = real_map

        self.is_3d_mode = False
        self.enable_heatmap = False
        self.enable_fog_of_war = False

        self.show_minimap = True
        self.minimap_x = None
        self.minimap_y = None
        self.minimap_w = 210
        self.minimap_h = 210
        self.minimap_dragging = False
        self.minimap_drag_offset = (0, 0)

        # Estrelas pre-calculadas para o fundo 3D (seed fixa)
        rng = _rnd.Random(42)
        self._stars = [
            (rng.randint(0, 1920), rng.randint(0, 1080),
             rng.randint(70, 210), rng.choice([1, 1, 1, 2]))
            for _ in range(240)
        ]

        self.font_small = pygame.font.SysFont("Segoe UI", 10, bold=True)
        self.font_icon  = pygame.font.SysFont("Segoe UI", 12, bold=True)
        self.font_hud   = pygame.font.SysFont("Segoe UI", 12, bold=True)
        self.font_mini  = pygame.font.SysFont("Segoe UI", 9)

    # ------------------------------------------------------------------
    # Controles de modo
    # ------------------------------------------------------------------
    def toggle_3d_mode(self):
        modes = ["2D", "3D_ORBIT", "FIRST_PERSON"]
        curr = getattr(self.camera, 'mode', "2D")
        idx = modes.index(curr) if curr in modes else 0
        self.set_view_mode(modes[(idx + 1) % len(modes)])

    def set_view_mode(self, mode_name: str):
        if hasattr(self.camera, 'set_mode'):
            self.camera.set_mode(mode_name)
        if mode_name == "FIRST_PERSON":
            start = getattr(self.grid, 'start_cell', None)
            if start and hasattr(self.camera, 'set_player_pos'):
                self.camera.set_player_pos(start.row, start.col)
            self.show_minimap = True

    def toggle_minimap(self):
        self.show_minimap = not self.show_minimap

    def toggle_heatmap(self):
        self.enable_heatmap = not self.enable_heatmap

    def toggle_fog_of_war(self):
        self.enable_fog_of_war = not self.enable_fog_of_war

    def handle_minimap_event(self, event) -> bool:
        if getattr(self.camera, 'mode', '2D') == '2D':
            return False
        if not self.show_minimap or self.minimap_x is None:
            return False
        x, y, w = self.minimap_x, self.minimap_y, self.minimap_w
        title_rect = pygame.Rect(x, y, w, 24)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if title_rect.collidepoint(event.pos):
                self.minimap_dragging = True
                self.minimap_drag_offset = (event.pos[0] - x, event.pos[1] - y)
                return True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.minimap_dragging:
                self.minimap_dragging = False
                return True
        elif event.type == pygame.MOUSEMOTION:
            if self.minimap_dragging:
                self.minimap_x = event.pos[0] - self.minimap_drag_offset[0]
                self.minimap_y = event.pos[1] - self.minimap_drag_offset[1]
                return True
        return False

    # ------------------------------------------------------------------
    # DISPATCHER PRINCIPAL
    # ------------------------------------------------------------------
    def render_world(self, viewport_w: int = None, viewport_h: int = None):
        if viewport_w is None or viewport_h is None:
            viewport_w, viewport_h = self.screen.get_size()

        # Se estiver no Modo Mapa Real Vetorial, renderiza o mapa vetorial de forma isolada
        app_mode = getattr(self.ui_mgr, 'app_mode', "MAZE")
        real_map = self.real_map or getattr(self.ui_mgr, 'real_map', None)
        if app_mode == "REAL_MAP" and real_map:
            sidebar_w = getattr(self.ui_mgr, 'sidebar_width', 230) if not getattr(self.ui_mgr, 'is_collapsed', False) else getattr(self.ui_mgr, 'collapsed_width', 35)
            vp_rect = pygame.Rect(sidebar_w, 0, max(10, viewport_w - sidebar_w), viewport_h)
            real_map.draw(self.screen, vp_rect)
            return

        cam_mode = getattr(self.camera, 'mode', '2D')
        if self.minimap_x is None:
            self.minimap_x = viewport_w - self.minimap_w - 10
            self.minimap_y = viewport_h - self.minimap_h - 10

        if cam_mode == '3D_ORBIT':
            self._render_grid_3d_orbital(viewport_w, viewport_h)
        elif cam_mode == 'FIRST_PERSON':
            self._render_first_person(viewport_w, viewport_h)
        else:
            self._render_grid_2d(viewport_w, viewport_h)
            if self.enable_fog_of_war:
                self._apply_fog_of_war(viewport_w, viewport_h)

        if cam_mode in ('3D_ORBIT', 'FIRST_PERSON') and self.show_minimap:
            self._render_minimap(viewport_w, viewport_h)

    # ==========================================
    # --- MODO 1: 2D CLASSICO (CENTRALIZADO) ---
    # ==========================================
    def _render_grid_2d(self, viewport_w, viewport_h):
        self.screen.fill(getattr(config, 'COLOR_BACKGROUND', (30, 34, 42)))
        cell_size  = getattr(config, 'CELL_SIZE', 20)
        zoom_level = getattr(self.camera, 'zoom_level', 1.0)

        # Centralização exata do labirinto no espaço visível fora da barra lateral
        sidebar_w = getattr(self.ui_mgr, 'sidebar_width', 230) if not getattr(self.ui_mgr, 'is_collapsed', False) else getattr(self.ui_mgr, 'collapsed_width', 35)
        avail_w = max(100, viewport_w - sidebar_w)
        avail_h = max(100, viewport_h)
        grid_total_w = self.grid.cols * cell_size
        grid_total_h = self.grid.rows * cell_size

        if getattr(self.grid, 'needs_recentering', True):
            self.grid.render_offset_x = sidebar_w + max(0, (avail_w - grid_total_w) // 2)
            self.grid.render_offset_y = max(0, (avail_h - grid_total_h) // 2)
            self.grid.needs_recentering = False

        offset_x = getattr(self.grid, 'render_offset_x', 0)
        offset_y = getattr(self.grid, 'render_offset_y', 0)

        for r in range(self.grid.rows):
            for c in range(self.grid.cols):
                cell = self.grid.get_cell(r, c)
                if not cell:
                    continue
                wx = c * cell_size + offset_x
                wy = r * cell_size + offset_y
                sx, sy = self.camera.world_to_screen(wx, wy)
                sw = max(1, int(cell_size * zoom_level))
                if sx + sw < 0 or sy + sw < 0 or sx > viewport_w or sy > viewport_h:
                    continue
                color = self._get_cell_color(cell)
                pygame.draw.rect(self.screen, color, (sx, sy, sw, sw))
                if sw > 4:
                    pygame.draw.rect(self.screen, (20, 22, 28), (sx, sy, sw, sw), 1)
                self._draw_cell_decorations_2d(cell, sx, sy, sw)


    def _draw_cell_decorations_2d(self, cell, sx, sy, sw):
        cx = sx + sw // 2
        cy = sy + sw // 2
        badge_radius = max(3, sw // 3)
        TYPE_WAYPOINT = getattr(config, 'TYPE_WAYPOINT', 4)
        TYPE_KEY      = getattr(config, 'TYPE_KEY', 5)
        TYPE_DOOR     = getattr(config, 'TYPE_DOOR', 6)
        TYPE_PORTAL   = getattr(config, 'TYPE_PORTAL', 7)

        if cell.type == TYPE_WAYPOINT:
            pygame.draw.circle(self.screen, (243, 156, 18), (cx, cy), badge_radius)
            pygame.draw.circle(self.screen, (255, 200, 0),  (cx, cy), badge_radius, 1)
            if sw > 14:
                s = self.font_small.render(str(getattr(cell, 'waypoint_order', 1) or 1), True, (20, 20, 20))
                self.screen.blit(s, s.get_rect(center=(cx, cy)))
        elif cell.type == TYPE_KEY:
            pid = getattr(cell, 'key_id', 1) or 1
            kc = config.get_pair_color(pid)
            pygame.draw.circle(self.screen, kc,           (cx, cy), badge_radius)
            pygame.draw.circle(self.screen, (255,255,255), (cx, cy), badge_radius, 1)
            if sw > 14:
                s = self.font_small.render(f"K{pid}", True, (255,255,255))
                self.screen.blit(s, s.get_rect(center=(cx, cy)))
        elif cell.type == TYPE_DOOR:
            pid = getattr(cell, 'door_id', 1) or 1
            dc = config.get_pair_color(pid)
            rect = pygame.Rect(sx + sw//4, sy + sw//4, sw//2, sw//2)
            pygame.draw.rect(self.screen, dc, rect)
            pygame.draw.rect(self.screen, (255,255,255), rect, 1)
            if sw > 14:
                s = self.font_small.render(f"D{pid}", True, (255,255,255))
                self.screen.blit(s, s.get_rect(center=(cx, cy)))
        elif cell.type == TYPE_PORTAL:
            pygame.draw.circle(self.screen, (52, 152, 219), (cx, cy), badge_radius, 2)
            pygame.draw.circle(self.screen, (155, 89, 182), (cx, cy), max(1, badge_radius - 3))

    # ==========================================
    # --- MODO 2: 3D ORBITAL (HOLOGRAMA) ------
    # ==========================================
    def _render_grid_3d_orbital(self, viewport_w, viewport_h):
        """Holograma 3D — ZERO Surface() por celula, sem lag."""
        t = time.time()
        cell_size = getattr(config, 'CELL_SIZE', 20)
        center_x = (self.grid.cols * cell_size) / 2.0
        center_y = (self.grid.rows * cell_size) / 2.0
        pulse = math.sin(t * 2.8)

        # Fundo espacial (estrelas pre-calculadas)
        self.screen.fill((5, 7, 16))
        for sx, sy, br, size in self._stars:
            b2 = min(255, br + int(math.sin(t * 0.7 + sx * 0.01) * 20))
            pygame.draw.circle(self.screen, (b2, b2, b2), (sx % viewport_w, sy % viewport_h), size)

        # Coleta e ordenacao back-to-front
        render_items = []
        for r in range(self.grid.rows):
            for c in range(self.grid.cols):
                cell = self.grid.get_cell(r, c)
                if not cell:
                    continue
                wx = (c + 0.5) * cell_size
                wy = (r + 0.5) * cell_size
                if cell.is_wall:
                    h = cell_size * 1.6
                elif cell.type in (getattr(config, 'TYPE_KEY', 5),
                                   getattr(config, 'TYPE_DOOR', 6),
                                   getattr(config, 'TYPE_WAYPOINT', 4)):
                    h = cell_size * 0.9
                elif cell.is_start or cell.is_end:
                    h = cell_size * 0.55
                elif cell.is_path:
                    h = cell_size * 0.2
                elif cell.visited:
                    h = cell_size * 0.06
                else:
                    h = 0.0
                _, _, depth = self.camera.project_3d_point(wx, wy, h / 2.0, center_x, center_y)
                render_items.append((depth, cell, r, c, h))

        render_items.sort(key=lambda item: item[0])

        neon_v = int(pulse * 25 + 200)
        neon_edge = (0, neon_v, 255)
        neon_top  = (0, min(255, neon_v + 30), 255)
        W_DARK = (4, 16, 34);  W_MID = (6, 22, 46);  W_SIDE = (4, 18, 38)

        for _, cell, r, c, h in render_items:
            wx0, wy0 = c * cell_size, r * cell_size
            wx1, wy1 = (c + 1) * cell_size, (r + 1) * cell_size

            p0 = self.camera.project_3d_point(wx0, wy0, 0.0, center_x, center_y)[:2]
            p1 = self.camera.project_3d_point(wx1, wy0, 0.0, center_x, center_y)[:2]
            p2 = self.camera.project_3d_point(wx1, wy1, 0.0, center_x, center_y)[:2]
            p3 = self.camera.project_3d_point(wx0, wy1, 0.0, center_x, center_y)[:2]
            p4 = self.camera.project_3d_point(wx0, wy0, h,   center_x, center_y)[:2]
            p5 = self.camera.project_3d_point(wx1, wy0, h,   center_x, center_y)[:2]
            p6 = self.camera.project_3d_point(wx1, wy1, h,   center_x, center_y)[:2]
            p7 = self.camera.project_3d_point(wx0, wy1, h,   center_x, center_y)[:2]

            if cell.is_wall:
                try:
                    pygame.draw.polygon(self.screen, W_SIDE, [p0,p3,p7,p4])
                    pygame.draw.polygon(self.screen, W_DARK, [p3,p2,p6,p7])
                    pygame.draw.polygon(self.screen, W_MID,  [p2,p1,p5,p6])
                    pygame.draw.polygon(self.screen, W_SIDE, [p1,p0,p4,p5])
                    pygame.draw.polygon(self.screen, W_DARK, [p4,p5,p6,p7])
                except Exception:
                    pass
                try:
                    for ea, eb in [(p0,p1),(p1,p2),(p2,p3),(p3,p0),
                                   (p4,p5),(p5,p6),(p6,p7),(p7,p4),
                                   (p0,p4),(p1,p5),(p2,p6),(p3,p7)]:
                        pygame.draw.line(self.screen, neon_edge, ea, eb, 1)
                    for ea, eb in [(p4,p5),(p5,p6),(p6,p7),(p7,p4)]:
                        pygame.draw.line(self.screen, neon_top, ea, eb, 2)
                except Exception:
                    pass

            elif h > 0.5:
                if cell.is_start:
                    fc=(15,160,65);   ec=(60,255,120)
                elif cell.is_end:
                    ep=int(pulse*40+210); fc=(ep,30,30); ec=(255,100,100)
                elif cell.type == getattr(config, 'TYPE_WAYPOINT', 4):
                    fc=(140,90,0);    ec=(255,200,0)
                elif cell.type == getattr(config, 'TYPE_KEY', 5):
                    pid=getattr(cell,'key_id',1) or 1
                    fc=config.get_pair_color(pid); ec=tuple(min(255,v+90) for v in fc)
                elif cell.type == getattr(config, 'TYPE_DOOR', 6):
                    pid=getattr(cell,'door_id',1) or 1
                    fc=config.get_pair_color(pid); ec=tuple(min(255,v+90) for v in fc)
                elif cell.is_path:
                    pv=int(pulse*35+190); fc=(pv,155,10); ec=(255,220,60)
                else:
                    fc=self._get_cell_color(cell); ec=tuple(min(255,v+50) for v in fc)

                fd=tuple(max(0,v-50) for v in fc)
                fm=tuple(max(0,v-25) for v in fc)
                try:
                    pygame.draw.polygon(self.screen, fm,  [p0,p3,p7,p4])
                    pygame.draw.polygon(self.screen, fd,  [p3,p2,p6,p7])
                    pygame.draw.polygon(self.screen, fm,  [p1,p0,p4,p5])
                    pygame.draw.polygon(self.screen, fc,  [p4,p5,p6,p7])
                except Exception:
                    pass
                try:
                    for ea,eb in [(p4,p5),(p5,p6),(p6,p7),(p7,p4)]:
                        pygame.draw.line(self.screen, ec, ea, eb, 2)
                    for ea,eb in [(p0,p4),(p1,p5),(p2,p6),(p3,p7)]:
                        pygame.draw.line(self.screen, ec, ea, eb, 1)
                except Exception:
                    pass

                cxt=(p4[0]+p6[0])//2; cyt=(p4[1]+p6[1])//2
                if cell.type == getattr(config,'TYPE_WAYPOINT',4):
                    s=self.font_icon.render(str(getattr(cell,'waypoint_order',1) or 1),True,(255,230,60))
                elif cell.type == getattr(config,'TYPE_KEY',5):
                    s=self.font_small.render(f"K{getattr(cell,'key_id',1) or 1}",True,(255,255,255))
                elif cell.type == getattr(config,'TYPE_DOOR',6):
                    s=self.font_small.render(f"D{getattr(cell,'door_id',1) or 1}",True,(255,255,255))
                elif cell.is_start:
                    s=self.font_small.render("S",True,(255,255,255))
                elif cell.is_end:
                    s=self.font_icon.render("★",True,(255,220,60))
                else:
                    s=None
                if s:
                    self.screen.blit(s, s.get_rect(center=(cxt,cyt)))

            elif cell.is_path:
                pv=int(pulse*30+190)
                try:
                    pygame.draw.polygon(self.screen,(pv,160,10),[p0,p1,p2,p3])
                    pygame.draw.polygon(self.screen,(255,220,60),[p0,p1,p2,p3],width=1)
                except Exception:
                    pass
            elif cell.visited:
                try:
                    pygame.draw.polygon(self.screen,(18,55,120),[p0,p1,p2,p3])
                    pygame.draw.polygon(self.screen,(0,80,160),[p0,p1,p2,p3],width=1)
                except Exception:
                    pass
            else:
                try:
                    pygame.draw.polygon(self.screen,(6,12,24),[p0,p1,p2,p3])
                    pygame.draw.polygon(self.screen,(0,50,80),[p0,p1,p2,p3],width=1)
                except Exception:
                    pass

        # Agente achador
        pf = getattr(self.ui_mgr,'pathfinding',None)
        if pf and getattr(pf,'is_running',False) and getattr(pf,'open_set',None):
            try:
                hc=pf.open_set[0][1]
                hx=(hc.col+0.5)*cell_size; hy=(hc.row+0.5)*cell_size
                hsx,hsy,_=self.camera.project_3d_point(hx,hy,cell_size*2.4,center_x,center_y)
                hr=int(11+pulse*4)
                pygame.draw.circle(self.screen,(0,200,255),(hsx,hsy),hr+5,2)
                pygame.draw.circle(self.screen,(0,230,255),(hsx,hsy),hr,2)
                pygame.draw.circle(self.screen,(255,255,255),(hsx,hsy),4)
            except Exception:
                pass

        # HUD
        nv=int(pulse*12+210)
        hint=self.font_hud.render(
            "3D ORBITAL  \u00b7  Btn Dir+Arrastar = Rotacionar  \u00b7  Scroll = Zoom  \u00b7  Meio+Arrastar = Pan  \u00b7  F3 = Modo",
            True,(0,nv,255))
        hw=hint.get_width()+28
        pygame.draw.rect(self.screen,(6,10,22),pygame.Rect(240,7,hw,26),border_radius=5)
        pygame.draw.rect(self.screen,(0,nv,255),pygame.Rect(240,7,hw,26),1,border_radius=5)
        self.screen.blit(hint,(254,13))

    # ==========================================
    # --- MODO 3: PRIMEIRA PESSOA (FPS) --------
    # ==========================================
    def _render_first_person(self, viewport_w, viewport_h):
        """Raycasting DDA com gradiente, bussola, indicadores de saida."""
        t = time.time()
        half_h = viewport_h // 2

        # Gradiente de teto
        step_c = max(1, half_h // 32)
        for band in range(0, half_h, step_c):
            ratio = band / float(half_h)
            pygame.draw.rect(self.screen,
                             (int(6+ratio*18), int(8+ratio*22), int(16+ratio*42)),
                             (0, band, viewport_w, step_c))

        # Gradiente de chao
        step_f = max(1, half_h // 32)
        for band in range(0, half_h, step_f):
            ratio = band / float(half_h)
            pygame.draw.rect(self.screen,
                             (int(26-ratio*16), int(22-ratio*13), int(18-ratio*10)),
                             (0, half_h+band, viewport_w, step_f))

        pr = self.camera.player_row
        pc = self.camera.player_col
        p_dir = self.camera.player_dir

        dir_angles   = [-math.pi/2, 0.0, math.pi/2, math.pi]
        player_angle = dir_angles[p_dir]
        fov   = math.pi / 3.0
        num_rays = 320
        col_w = viewport_w / float(num_rays)

        for i in range(num_rays):
            ray_angle = player_angle - fov*0.5 + (i/float(num_rays))*fov
            cos_a = math.cos(ray_angle)
            sin_a = math.sin(ray_angle)
            map_x = int(pc); map_y = int(pr)
            ddx = abs(1.0/cos_a) if cos_a != 0 else 1e30
            ddy = abs(1.0/sin_a) if sin_a != 0 else 1e30
            step_x = 1 if cos_a >= 0 else -1
            step_y = 1 if sin_a >= 0 else -1
            sdx = ((map_x+1.0)-(pc+0.5))*ddx if cos_a >= 0 else ((pc+0.5)-map_x)*ddx
            sdy = ((map_y+1.0)-(pr+0.5))*ddy if sin_a >= 0 else ((pr+0.5)-map_y)*ddy

            hit=False; hit_cell=None; side=0; steps=0
            while not hit and steps < 40:
                steps += 1
                if sdx < sdy:
                    sdx += ddx; map_x += step_x; side=0
                else:
                    sdy += ddy; map_y += step_y; side=1
                cc = self.grid.get_cell(map_y, map_x)
                if not cc or cc.is_wall or cc.type == getattr(config,'TYPE_DOOR',6):
                    hit=True; hit_cell=cc

            if hit and hit_cell:
                raw_d = (sdx-ddx) if side==0 else (sdy-ddy)
                perp  = max(0.1, raw_d*math.cos(ray_angle-player_angle))
                wh    = int(viewport_h/perp)
                top   = max(0, (viewport_h-wh)//2)
                bot   = min(viewport_h, (viewport_h+wh)//2)

                if hit_cell.type == getattr(config,'TYPE_DOOR',6):
                    pid=getattr(hit_cell,'door_id',1) or 1
                    bc=config.get_pair_color(pid)
                    pv=0.82+math.sin(t*3.2)*0.18
                    bc=(int(bc[0]*pv),int(bc[1]*pv),int(bc[2]*pv))
                else:
                    bc=(58,68,88) if side==0 else (44,52,70)
                    grain=int((i%3)*2)
                    bc=(bc[0]+grain, bc[1]+grain, bc[2])

                fog=max(0.06, 1.0-perp/20.0)
                wc=(int(bc[0]*fog),int(bc[1]*fog),int(bc[2]*fog))
                cr=pygame.Rect(int(i*col_w),top,max(1,int(col_w)+1),bot-top)
                pygame.draw.rect(self.screen, wc, cr)

                bl=(min(255,wc[0]+35),min(255,wc[1]+30),min(255,wc[2]+40))
                if top > 0:
                    pygame.draw.line(self.screen, bl, (cr.left,top), (cr.right,top))
                if bot < viewport_h:
                    pygame.draw.line(self.screen, bl, (cr.left,bot), (cr.right,bot))

        # Indicadores de saida e waypoints
        self._draw_fp_goal_indicators(viewport_w, viewport_h, pr, pc, player_angle, fov, t)

        # Crosshair
        cxs, cys = viewport_w//2, viewport_h//2
        pygame.draw.line(self.screen,(220,235,255),(cxs-10,cys),(cxs+10,cys),1)
        pygame.draw.line(self.screen,(220,235,255),(cxs,cys-10),(cxs,cys+10),1)
        pygame.draw.circle(self.screen,(220,235,255),(cxs,cys),4,1)

        # Bussola
        self._draw_compass(viewport_w, viewport_h, p_dir)

        # HUD superior (solido)
        hx,hy,hw,hh = 240,10,viewport_w-260,48
        pygame.draw.rect(self.screen,(12,16,26),(hx,hy,hw,hh),border_radius=8)
        pygame.draw.rect(self.screen,(0,140,180),(hx,hy,hw,hh),1,border_radius=8)

        dir_labels  = ["\u25b2 NORTE","\u25b6 LESTE","\u25bc SUL","\u25c4 OESTE"]
        dir_colours = [(80,230,120),(100,210,255),(230,100,80),(210,160,255)]
        fhud = pygame.font.SysFont("Segoe UI",13,bold=True)
        fsm  = pygame.font.SysFont("Segoe UI",11)

        self.screen.blit(fhud.render(dir_labels[p_dir],True,dir_colours[p_dir]), (hx+14,hy+6))
        self.screen.blit(fsm.render(f"Pos ({pr}, {pc})",True,(160,170,190)), (hx+14,hy+28))

        kx = hx+130
        self.screen.blit(fsm.render("Chaves:",True,(120,130,150)), (kx,hy+8))
        collected = sorted(self.camera.player_collected_keys)
        for ki,kid in enumerate(collected):
            self.screen.blit(fhud.render(f"K{kid}",True,config.get_pair_color(kid)), (kx+55+ki*34,hy+6))
        if not collected:
            self.screen.blit(fsm.render("Nenhuma",True,(80,90,105)), (kx+55,hy+8))

        msg = getattr(self.camera,'last_move_message','')
        if msg:
            ms = pygame.font.SysFont("Segoe UI",14,bold=True).render(msg,True,(255,215,60))
            mw = ms.get_width()+24
            pygame.draw.rect(self.screen,(10,14,24),(hx,hy+hh+5,mw,28),border_radius=6)
            pygame.draw.rect(self.screen,(200,160,0),(hx,hy+hh+5,mw,28),1,border_radius=6)
            self.screen.blit(ms,(hx+12,hy+hh+10))

        # Barra de controles rodape (solida)
        ctrl_y = viewport_h-30
        pygame.draw.rect(self.screen,(10,14,22),(hx,ctrl_y,hw,24),border_radius=5)
        pygame.draw.rect(self.screen,(35,50,65),(hx,ctrl_y,hw,24),1,border_radius=5)
        ctrl_parts = [("W/\u2191","Avan\u00e7ar"),("S/\u2193","Recuar"),
                      ("A/\u2190","Girar Esq"),("D/\u2192","Girar Dir"),
                      ("M","Mapa"),("F3","Modo")]
        fck = pygame.font.SysFont("Consolas",10,bold=True)
        fcv = pygame.font.SysFont("Segoe UI",10)
        cx_p = hx+10
        for kl,vl in ctrl_parts:
            ks=fck.render(f"[{kl}]",True,(0,190,235))
            vs=fcv.render(f" {vl}",True,(140,150,165))
            self.screen.blit(ks,(cx_p,ctrl_y+6)); cx_p+=ks.get_width()
            self.screen.blit(vs,(cx_p,ctrl_y+6)); cx_p+=vs.get_width()+14

    def _draw_fp_goal_indicators(self, viewport_w, viewport_h, pr, pc, player_angle, fov, t):
        """Setas na borda da tela apontando para saida e waypoints."""
        targets = []
        end_cells = getattr(self.grid,'end_cells',[])
        for ec in end_cells:
            targets.append((ec.row, ec.col, (255,80,80), "\u2605 SA\u00cdDA"))

        wps_added = 0
        for rr in range(self.grid.rows):
            for cc in range(self.grid.cols):
                ccc = self.grid.get_cell(rr, cc)
                if ccc and ccc.type == getattr(config,'TYPE_WAYPOINT',4):
                    targets.append((rr, cc, (255,200,0), f"WP{getattr(ccc,'waypoint_order',1) or 1}"))
                    wps_added += 1
                    if wps_added >= 2:
                        break
            if wps_added >= 2:
                break

        cy_screen = viewport_h // 2

        for tr,tc,col,label in targets:
            fdx = tc-pc; fdy = tr-pr
            dist = math.sqrt(fdx*fdx + fdy*fdy)
            if dist < 1.5:
                continue
            goal_angle = math.atan2(fdy, fdx)
            angle_diff = goal_angle - player_angle
            while angle_diff >  math.pi: angle_diff -= 2*math.pi
            while angle_diff < -math.pi: angle_diff += 2*math.pi

            if abs(angle_diff) <= fov*0.48:
                # Dentro do FOV: icone flutuante
                screen_col = int((angle_diff+fov/2.0)/fov*viewport_w)
                icon_y     = int(viewport_h*0.28 + math.sin(t*2.5)*8)
                pr_r       = int(6 + math.sin(t*3)*2)
                pygame.draw.circle(self.screen, col, (screen_col,icon_y), pr_r+3, 2)
                pygame.draw.circle(self.screen, (255,255,255), (screen_col,icon_y), pr_r)
                lbl_s = pygame.font.SysFont("Segoe UI",10,bold=True).render(label,True,col)
                self.screen.blit(lbl_s, lbl_s.get_rect(center=(screen_col,icon_y-16)))
                for yy in range(icon_y+pr_r+2, viewport_h//2, 5):
                    pygame.draw.line(self.screen, col, (screen_col,yy), (screen_col,yy+3), 1)
            else:
                # Fora do FOV: seta na borda
                sign   = 1 if angle_diff > 0 else -1
                edge_x = viewport_w-38 if sign > 0 else 30
                pva    = math.sin(t*3.5)*0.3+0.7
                ac     = (int(col[0]*pva),int(col[1]*pva),int(col[2]*pva))
                if sign > 0:
                    pts = [(edge_x,cy_screen-12),(edge_x+14,cy_screen),(edge_x,cy_screen+12)]
                else:
                    pts = [(edge_x,cy_screen-12),(edge_x-14,cy_screen),(edge_x,cy_screen+12)]
                pygame.draw.polygon(self.screen, ac, pts)
                pygame.draw.polygon(self.screen, (255,255,255), pts, 1)
                ds = pygame.font.SysFont("Segoe UI",9,bold=True).render(f"{int(dist)}c",True,col)
                self.screen.blit(ds, ds.get_rect(center=(edge_x,cy_screen+20)))

    def _draw_compass(self, viewport_w, viewport_h, p_dir):
        """Bussola circular solida (sem SRCALPHA)."""
        cx = viewport_w-52; cy=64; radius=38; inner_r=29
        pygame.draw.circle(self.screen,(12,16,28),(cx,cy),radius)
        pygame.draw.circle(self.screen,(0,140,185),(cx,cy),radius,2)
        pygame.draw.circle(self.screen,(0,80,110),(cx,cy),inner_r+2,1)

        fc = pygame.font.SysFont("Segoe UI",9,bold=True)
        cdirs = [("N",0,(80,230,110)),("L",1,(80,200,255)),
                 ("S",2,(230,90,70)), ("O",3,(200,150,255))]
        for label,direction,col in cdirs:
            angle = direction*math.pi/2 - math.pi/2
            lx=int(cx+(inner_r-3)*math.cos(angle))
            ly=int(cy+(inner_r-3)*math.sin(angle))
            bright=(255,255,255) if direction==p_dir else col
            s=fc.render(label,True,bright)
            self.screen.blit(s, s.get_rect(center=(lx,ly)))

        aa = p_dir*math.pi/2 - math.pi/2
        ax=int(cx+(inner_r-11)*math.cos(aa)); ay=int(cy+(inner_r-11)*math.sin(aa))
        perp=aa+math.pi/2
        s1=(int(cx+6*math.cos(perp)),int(cy+6*math.sin(perp)))
        s2=(int(cx-6*math.cos(perp)),int(cy-6*math.sin(perp)))
        arrow_col=[c for lbl,d,c in cdirs if d==p_dir][0]
        pygame.draw.polygon(self.screen,arrow_col,[(ax,ay),s1,s2])
        pygame.draw.polygon(self.screen,(255,255,255),[(ax,ay),s1,s2],1)
        pygame.draw.circle(self.screen,(0,180,216),(cx,cy),5)
        pygame.draw.circle(self.screen,(255,255,255),(cx,cy),5,1)

    # ==========================================
    # --- MODO 4: MINIMAPA 2D FLUTUANTE --------
    # ==========================================
    def _render_minimap(self, viewport_w, viewport_h):
        x,y,w,h = self.minimap_x,self.minimap_y,self.minimap_w,self.minimap_h
        pygame.draw.rect(self.screen,(20,24,32),(x,y,w,h),border_radius=8)
        pygame.draw.rect(self.screen,(50,60,75),(x,y,w,h),1,border_radius=8)
        title_rect=pygame.Rect(x,y,w,24)
        pygame.draw.rect(self.screen,(32,38,48),title_rect,border_top_left_radius=8,border_top_right_radius=8)
        pygame.draw.line(self.screen,(0,180,216),(x,y+24),(x+w,y+24),1)
        self.screen.blit(self.font_small.render("Minimapa 2D (Arraste aqui)",True,(0,180,216)),(x+8,y+5))

        inner_w=w-16; inner_h=h-34
        mini_size=min(inner_w/float(self.grid.cols), inner_h/float(self.grid.rows))
        grid_w=self.grid.cols*mini_size; grid_h=self.grid.rows*mini_size
        start_x=x+(w-grid_w)/2.0; start_y=y+26+(inner_h-grid_h)/2.0

        for r in range(self.grid.rows):
            for c in range(self.grid.cols):
                cell=self.grid.get_cell(r,c)
                if not cell: continue
                cx=int(start_x+c*mini_size); cy=int(start_y+r*mini_size)
                cw=max(1,int(mini_size))
                if cell.is_wall:              col=(40,44,52)
                elif cell.is_start:           col=(46,204,113)
                elif cell.is_end:             col=(231,76,60)
                elif cell.type==getattr(config,'TYPE_KEY',5):
                    col=config.get_pair_color(getattr(cell,'key_id',1) or 1)
                elif cell.type==getattr(config,'TYPE_DOOR',6):
                    col=config.get_pair_color(getattr(cell,'door_id',1) or 1)
                elif cell.type==getattr(config,'TYPE_WAYPOINT',4): col=(243,156,18)
                elif cell.is_path:            col=(241,196,15)
                elif cell.visited:            col=(52,152,219)
                else:                         col=(200,205,215)
                pygame.draw.rect(self.screen,col,(cx,cy,cw,cw))

        if getattr(self.camera,'mode','2D') == "FIRST_PERSON":
            pr=self.camera.player_row; pc=self.camera.player_col; p_dir=self.camera.player_dir
            px=int(start_x+(pc+0.5)*mini_size); py=int(start_y+(pr+0.5)*mini_size)
            pygame.draw.circle(self.screen,(0,255,255),(px,py),4)
            dr,dc=self.camera.DIR_OFFSETS[p_dir]
            pygame.draw.line(self.screen,(255,255,255),(px,py),(px+dc*7,py+dr*7),2)

    # ------------------------------------------------------------------
    # Utilitarios
    # ------------------------------------------------------------------
    def _get_cell_color(self, cell) -> tuple:
        if cell.is_wall:   return getattr(config,'COLOR_WALL',(40,44,52))
        if cell.is_start:  return getattr(config,'COLOR_START',(46,204,113))
        if cell.is_end:    return getattr(config,'COLOR_END',(231,76,60))
        if cell.is_path:   return (241,196,15)
        if self.enable_heatmap and (cell.visited or cell.is_open):
            intensity=min(255,int(cell.g_cost*5))
            return (intensity,max(0,255-intensity),180)
        if cell.visited:   return (52,152,219)
        if cell.is_open:   return (26,188,156)
        if cell.type==getattr(config,'TYPE_WAYPOINT',4): return getattr(config,'COLOR_WAYPOINT',(243,156,18))
        if cell.type==getattr(config,'TYPE_KEY',5):      return config.get_pair_color(getattr(cell,'key_id',1) or 1)
        if cell.type==getattr(config,'TYPE_DOOR',6):     return config.get_pair_color(getattr(cell,'door_id',1) or 1)
        if cell.type==getattr(config,'TYPE_PORTAL',7):   return (52,152,219)
        if cell.type==getattr(config,'TYPE_HAZARD',8):   return (192,57,43)
        return getattr(config,'COLOR_EMPTY',(220,224,230))

    def _apply_fog_of_war(self, viewport_w, viewport_h):
        fog_surface=pygame.Surface((viewport_w,viewport_h),pygame.SRCALPHA)
        fog_surface.fill((10,12,16,240))
        if self.grid.start_cell:
            cell_size=getattr(config,'CELL_SIZE',20)
            off_x = getattr(self.grid, 'render_offset_x', 0)
            off_y = getattr(self.grid, 'render_offset_y', 0)
            sx = (self.grid.start_cell.col * cell_size) + off_x
            sy = (self.grid.start_cell.row * cell_size) + off_y
            screen_x, screen_y = self.camera.world_to_screen(sx, sy)
            pygame.draw.circle(fog_surface, (0, 0, 0, 0), (screen_x, screen_y), int(180 * zoom_val))
        self.screen.blit(fog_surface, (0, 0))


    def render_ui(self):
        if self.ui_mgr and hasattr(self.ui_mgr,'draw'):
            self.ui_mgr.draw(self.screen)