import time
import pygame
import config
from utils.map_loader import MapLoadThread

class UIComponent:
    """Classe base para componentes interativos da interface."""
    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
        self.is_hovered = False
        self.visible = True

    def update_hover(self, mouse_pos):
        if self.visible:
            self.is_hovered = self.rect.collidepoint(mouse_pos)
        else:
            self.is_hovered = False

    def handle_event(self, event):
        pass

    def draw(self, surface):
        pass


class Button(UIComponent):
    """Botão moderno com gradiente suave e efeito de hover."""
    def __init__(self, x, y, width, height, text, callback, bg_color=None, text_color=None, icon=""):
        super().__init__(x, y, width, height)
        self.text = text
        self.callback = callback
        self.icon = icon
        
        self.bg_color = bg_color or (35, 39, 46)
        self.hover_color = (
            min(self.bg_color[0] + 30, 255),
            min(self.bg_color[1] + 30, 255),
            min(self.bg_color[2] + 35, 255)
        )
        self.text_color = text_color or (240, 240, 240)
        self.border_color = (60, 68, 81)

    def handle_event(self, event):
        if not self.visible: return False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.is_hovered and self.callback:
                self.callback()
                return True
        return False

    def draw(self, surface):
        if not self.visible: return
        color = self.hover_color if self.is_hovered else self.bg_color
        
        pygame.draw.rect(surface, color, self.rect, border_radius=6)
        pygame.draw.rect(surface, self.border_color, self.rect, width=1, border_radius=6)

        font = pygame.font.SysFont("Segoe UI", 12, bold=True)
        display_text = f"{self.icon} {self.text}".strip()
        text_surf = font.render(display_text, True, self.text_color)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)


class Dropdown(UIComponent):
    """Menu suspenso moderno com overlay flutuante no topo de todos os componentes."""
    def __init__(self, x, y, width, height, options, on_select, label=""):
        super().__init__(x, y, width, height)
        self.options = options
        self.selected_index = 0
        self.on_select = on_select
        self.label = label
        self.is_open = False
        self.option_height = height

    def get_popup_rect(self):
        """Retorna o retângulo correspondente à área das opções abertas."""
        if not self.is_open or not self.options:
            return pygame.Rect(0, 0, 0, 0)
        return pygame.Rect(
            self.rect.x,
            self.rect.bottom,
            self.rect.width,
            len(self.options) * self.option_height
        )

    def handle_event(self, event):
        if not self.visible:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # 1. Se estiver aberto, verifica clique em uma das opções
            if self.is_open:
                popup_rect = self.get_popup_rect()
                if popup_rect.collidepoint(event.pos):
                    relative_y = event.pos[1] - self.rect.bottom
                    idx = int(relative_y // self.option_height)
                    if 0 <= idx < len(self.options):
                        self.selected_index = idx
                        if self.on_select:
                            self.on_select(self.options[idx])
                    self.is_open = False
                    return True

                # Se clicou no próprio cabeçalho, fecha
                if self.rect.collidepoint(event.pos):
                    self.is_open = False
                    return True

                # Clicou fora da área do dropdown aberto: fecha
                self.is_open = False
                return False

            # 2. Se estiver fechado, clique no cabeçalho abre
            if self.rect.collidepoint(event.pos):
                self.is_open = True
                return True

        return False

    def draw_header(self, surface):
        """Desenha a caixa base do dropdown."""
        if not self.visible:
            return

        bg_color = (48, 55, 68) if self.is_hovered or self.is_open else (35, 39, 48)
        border_color = (0, 180, 216) if self.is_open else ((70, 82, 100) if self.is_hovered else (52, 60, 74))

        pygame.draw.rect(surface, bg_color, self.rect, border_radius=6)
        pygame.draw.rect(surface, border_color, self.rect, width=1, border_radius=6)

        font = pygame.font.SysFont("Segoe UI", 11)
        selected_text = self.options[self.selected_index] if self.options else ""
        text_surf = font.render(f"{self.label}: {selected_text}", True, (230, 235, 245))
        surface.blit(text_surf, (self.rect.x + 8, self.rect.y + (self.rect.height - text_surf.get_height()) // 2))

        arrow_color = (0, 180, 216) if self.is_open else (160, 170, 185)
        arrow_surf = font.render("▲" if self.is_open else "▼", True, arrow_color)
        surface.blit(arrow_surf, (self.rect.right - 18, self.rect.y + (self.rect.height - arrow_surf.get_height()) // 2))


    def draw_popup(self, surface):
        """Desenha a lista flutuante de opções no topo absoluto da interface com sombra e destaque."""
        if not self.visible or not self.is_open or not self.options:
            return

        popup_rect = self.get_popup_rect()
        mouse_pos = pygame.mouse.get_pos()

        # Sombra suave com transparência para profundidade visual
        shadow_rect = popup_rect.inflate(6, 6).move(2, 4)
        shadow_surf = pygame.Surface((shadow_rect.width, shadow_rect.height), pygame.SRCALPHA)
        shadow_surf.fill((0, 0, 0, 110))
        surface.blit(shadow_surf, (shadow_rect.x, shadow_rect.y))

        # Fundo do container flutuante
        pygame.draw.rect(surface, (24, 27, 34), popup_rect, border_radius=6)
        pygame.draw.rect(surface, (0, 180, 216), popup_rect, width=1, border_radius=6)

        font = pygame.font.SysFont("Segoe UI", 12)

        for i, option in enumerate(self.options):
            opt_rect = pygame.Rect(
                self.rect.x,
                self.rect.bottom + (i * self.option_height),
                self.rect.width,
                self.option_height
            )
            opt_hover = opt_rect.collidepoint(mouse_pos)
            is_selected = (i == self.selected_index)

            # Cor de fundo da opção
            if opt_hover:
                opt_bg = (45, 55, 72)
            elif is_selected:
                opt_bg = (32, 40, 52)
            else:
                opt_bg = (24, 27, 34)

            pygame.draw.rect(surface, opt_bg, opt_rect)

            # Linha divisória sutil entre itens
            if i < len(self.options) - 1:
                pygame.draw.line(surface, (40, 46, 58), 
                                 (opt_rect.left + 6, opt_rect.bottom - 1), 
                                 (opt_rect.right - 6, opt_rect.bottom - 1), 1)

            # Indicador de item selecionado
            if is_selected:
                ind_rect = pygame.Rect(opt_rect.left + 3, opt_rect.top + 4, 3, opt_rect.height - 8)
                pygame.draw.rect(surface, (0, 180, 216), ind_rect, border_radius=2)

            text_color = (255, 255, 255) if opt_hover else ((0, 180, 216) if is_selected else (200, 205, 215))
            opt_surf = font.render(option, True, text_color)
            surface.blit(opt_surf, (opt_rect.x + 12, opt_rect.y + (opt_rect.height - opt_surf.get_height()) // 2))


    def draw(self, surface):
        """Compatibilidade: desenha cabeçalho e popup."""
        self.draw_header(surface)
        if self.is_open:
            self.draw_popup(surface)


class Slider(UIComponent):
    """Barra deslizante para controle numérico."""
    def __init__(self, x, y, width, height, min_val, max_val, initial_val, on_change, label=""):
        super().__init__(x, y, width, height)
        self.min_val = min_val
        self.max_val = max_val
        self.val = initial_val
        self.on_change = on_change
        self.label = label
        self.is_dragging = False

    def handle_event(self, event):
        if not self.visible: return False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.is_dragging = True
                self._update_val(event.pos[0])
                return True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.is_dragging = False
        elif event.type == pygame.MOUSEMOTION and self.is_dragging:
            self._update_val(event.pos[0])
            return True
        return False

    def _update_val(self, mouse_x):
        rel_x = max(0, min(mouse_x - self.rect.x, self.rect.width))
        ratio = rel_x / self.rect.width
        self.val = self.min_val + ratio * (self.max_val - self.min_val)
        if self.on_change:
            self.on_change(self.val)

    def draw(self, surface):
        if not self.visible: return
        font = pygame.font.SysFont("Segoe UI", 11)
        label_surf = font.render(f"{self.label}: {int(self.val)}", True, (200, 200, 200))
        surface.blit(label_surf, (self.rect.x, self.rect.y - 18))

        rail_rect = pygame.Rect(self.rect.x, self.rect.y + self.rect.height // 2 - 2, self.rect.width, 4)
        pygame.draw.rect(surface, (50, 56, 68), rail_rect, border_radius=2)

        ratio = (self.val - self.min_val) / (self.max_val - self.min_val)
        fill_width = int(self.rect.width * ratio)
        fill_rect = pygame.Rect(self.rect.x, self.rect.y + self.rect.height // 2 - 2, fill_width, 4)
        pygame.draw.rect(surface, (0, 180, 216), fill_rect, border_radius=2)

        handle_x = self.rect.x + fill_width
        handle_center = (handle_x, self.rect.y + self.rect.height // 2)
        pygame.draw.circle(surface, (240, 240, 240), handle_center, 6)
        pygame.draw.circle(surface, (0, 180, 216), handle_center, 6, width=2)


class TextInput(UIComponent):
    """Campo de entrada de texto moderno com foco, cursor piscante e placeholder."""
    def __init__(self, x, y, width, height, placeholder="Buscar local...", default_text=""):
        super().__init__(x, y, width, height)
        self.text = default_text
        self.placeholder = placeholder
        self.is_focused = False
        self.cursor_visible = True
        self.cursor_timer = 0
        self.on_submit = None

        self.bg_color = (22, 26, 34)
        self.border_color = (55, 65, 80)
        self.focus_border_color = (0, 180, 216)
        self.text_color = (240, 245, 255)
        self.placeholder_color = (115, 125, 140)
        self.font = pygame.font.SysFont("Segoe UI", 11)

    def handle_event(self, event):
        if not self.visible:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            was_focused = self.is_focused
            self.is_focused = self.rect.collidepoint(event.pos)
            return self.is_focused or was_focused

        if event.type == pygame.KEYDOWN and self.is_focused:
            if event.key == pygame.K_RETURN:
                if self.on_submit:
                    self.on_submit(self.text)
                return True
            elif event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
                return True
            elif event.key == pygame.K_ESCAPE:
                self.is_focused = False
                return True
            else:
                if event.unicode and event.unicode.isprintable() and len(self.text) < 45:
                    self.text += event.unicode
                    return True
            return True

        return False

    def update(self):
        self.cursor_timer = (self.cursor_timer + 1) % 60
        self.cursor_visible = self.cursor_timer < 30

    def draw(self, surface):
        if not self.visible:
            return

        border = self.focus_border_color if self.is_focused else self.border_color
        pygame.draw.rect(surface, self.bg_color, self.rect, border_radius=5)
        pygame.draw.rect(surface, border, self.rect, width=1, border_radius=5)

        display_text = self.text if self.text else self.placeholder
        text_col = self.text_color if self.text else self.placeholder_color

        rendered = self.font.render(display_text, True, text_col)
        text_w = rendered.get_width()
        max_w = self.rect.width - 12
        clip_rect = pygame.Rect(self.rect.x + 6, self.rect.y + 2, max_w, self.rect.height - 4)

        surface.set_clip(clip_rect)
        if text_w > max_w:
            surface.blit(rendered, (self.rect.x + 6 - (text_w - max_w), self.rect.y + (self.rect.height - rendered.get_height()) // 2))
        else:
            surface.blit(rendered, (self.rect.x + 6, self.rect.y + (self.rect.height - rendered.get_height()) // 2))

        if self.is_focused and self.cursor_visible:
            cx = min(self.rect.x + 6 + text_w, self.rect.right - 6)
            cy1 = self.rect.y + 4
            cy2 = self.rect.bottom - 4
            pygame.draw.line(surface, (0, 180, 216), (cx, cy1), (cx, cy2), 1)

        surface.set_clip(None)


class InterfaceManager:
    """Gerenciador da barra lateral com alternância entre Modo Labirinto e Modo Mapa Real Vetorial."""
    def __init__(self, window_width, window_height, grid, pathfinding_mgr, maze_gen_mgr):
        self.width = window_width
        self.height = window_height
        self.grid = grid
        self.pathfinding = pathfinding_mgr
        self.generator = maze_gen_mgr

        self.sidebar_width = 230
        self.collapsed_width = 35
        self.is_collapsed = False
        self.active_tool = "WALL"
        self.current_pair_id = 1
        self.interactive_mgr = getattr(grid, 'interactive_mgr', None)
        self.renderer = None
        self.real_map = None

        self.app_mode = "MAZE"   # "MAZE" (Labirinto Clássico) ou "REAL_MAP" (Mapa Real Vetorial)
        self.custom_rows = 30
        self.custom_cols = 40

        # Carregador assíncrono do OSM
        self.map_thread = None
        self.map_status = "Digite um local e carregue"
        self.map_status_color = (140, 150, 165)
        self.real_map_speed = 5

        self.maze_components = []
        self.real_map_components = []
        self.components = []

        self._init_ui()

    def set_renderer(self, renderer):
        self.renderer = renderer

    def set_real_map(self, real_map):
        self.real_map = real_map

    def _init_ui(self):
        self.maze_components.clear()
        self.real_map_components.clear()

        # Botão recolher barra
        self.btn_toggle = Button(5, 5, 22, 24, "—", self.toggle_collapse, bg_color=(45, 50, 60))

        # Abas de Alternância de Modo no topo da barra lateral
        self.btn_tab_maze = Button(30, 5, 96, 24, "Labirinto", lambda: self.set_app_mode("MAZE"),
                                   bg_color=(0, 150, 185), text_color=(255, 255, 255))
        self.btn_tab_map  = Button(130, 5, 96, 24, "Mapa Real", lambda: self.set_app_mode("REAL_MAP"),
                                   bg_color=(35, 40, 52), text_color=(180, 190, 205))

        # ==========================================================
        # 1. COMPONENTES DO MODO LABIRINTO (CLÁSSICO)
        # ==========================================================
        x = 12
        y = 35

        algo_options = ["A*", "Dijkstra", "BFS", "DFS"]
        self.dd_algo = Dropdown(x, y, 205, 26, algo_options, self.pathfinding.set_algorithm, label="Busca")
        self.maze_components.append(self.dd_algo)

        y += 32
        self.btn_play = Button(x, y, 64, 26, "Play", self.pathfinding.toggle_start, bg_color=(0, 150, 136), icon="▶")
        self.btn_step = Button(x + 68, y, 64, 26, "Passo", self.pathfinding.step, bg_color=(60, 110, 180), icon="⏯")
        self.btn_reset = Button(x + 136, y, 68, 26, "Reset", self.pathfinding.reset, bg_color=(190, 50, 60), icon="↺")
        self.maze_components.extend([self.btn_play, self.btn_step, self.btn_reset])

        y += 38
        self.sld_speed = Slider(x, y, 205, 16, 1, 120, 60, self.pathfinding.set_speed, label="Velocidade (FPS)")
        self.maze_components.append(self.sld_speed)

        y += 28
        gen_options = ["DFS Generator", "Prim", "Divisao Recursiva", "Caos"]
        self.dd_gen = Dropdown(x, y, 205, 26, gen_options, self._run_generator, label="Gerar")
        self.maze_components.append(self.dd_gen)

        y += 32
        size_options = ["Pequeno (15x20)", "Médio (30x40)", "Grande (50x60)", "Personalizado"]
        self.dd_size = Dropdown(x, y, 205, 26, size_options, self._on_size_select, label="Tamanho")
        self.maze_components.append(self.dd_size)

        y += 38
        self.sld_rows = Slider(x, y, 95, 16, 5, 200, 30, self._set_custom_rows, label="Linhas")
        self.sld_cols = Slider(x + 110, y, 95, 16, 5, 200, 40, self._set_custom_cols, label="Colunas")
        self.sld_rows.visible = False
        self.sld_cols.visible = False
        self.btn_apply_size = Button(x, y + 20, 205, 24, "Aplicar Tamanho", self._apply_custom_size, bg_color=(46, 204, 113))
        self.btn_apply_size.visible = False
        self.maze_components.extend([self.sld_rows, self.sld_cols, self.btn_apply_size])

        y += 4
        tools = [
            ("Parede", "WALL", (40, 40, 45)),
            ("Borracha", "ERASER", (149, 165, 166)),
            ("Inicio", "START", (46, 204, 113)),
            ("Fim", "END", (231, 76, 60)),
            ("Waypoint", "WAYPOINT", (241, 196, 15)),
            ("Portal", "PORTAL", (52, 152, 219)),
            ("Chave", "KEY", (155, 89, 182)),
            ("Porta", "DOOR", (211, 84, 0))
        ]

        tx, ty = x, y
        for i, (name, mode, color) in enumerate(tools):
            bx = tx + (i % 2) * 105
            by = ty + (i // 2) * 28
            btn = Button(bx, by, 100, 24, name, lambda m=mode: self.set_tool(m), bg_color=color)
            self.maze_components.append(btn)

        y_pair = by + 28
        self.btn_prev_pair = Button(x, y_pair, 32, 24, "<", self._prev_pair_id, bg_color=(45, 50, 60))
        pair_col = getattr(config, 'get_pair_color', lambda p: (0, 210, 211))(self.current_pair_id)
        self.btn_pair_display = Button(x + 36, y_pair, 133, 24, f"Par: {self.current_pair_id}", None, bg_color=pair_col, text_color=(15, 15, 20))
        self.btn_next_pair = Button(x + 173, y_pair, 32, 24, ">", self._next_pair_id, bg_color=(45, 50, 60))
        self.maze_components.extend([self.btn_prev_pair, self.btn_pair_display, self.btn_next_pair])

        y_clear = y_pair + 28
        self.btn_clear = Button(x, y_clear, 205, 26, "Limpar Labirinto", self._clear_all_maze, bg_color=(192, 57, 43))
        self.maze_components.append(self.btn_clear)

        y_view = y_clear + 32
        view_options = ["2D Clássico", "3D Orbital", "1ª Pessoa"]
        self.dd_view = Dropdown(x, y_view, 205, 26, view_options, self._on_view_mode_change, label="Visão")
        self.maze_components.append(self.dd_view)

        y_minimap = y_view + 30
        self.btn_minimap = Button(x, y_minimap, 205, 24, "Minimapa: ON", self._toggle_minimap, bg_color=(44, 62, 80), icon="🗺")
        self.maze_components.append(self.btn_minimap)

        # ==========================================================
        # 2. COMPONENTES DO MODO MAPA REAL (VETORIAL)
        # ==========================================================
        ym = 38
        self.input_map = TextInput(x, ym, 205, 26, placeholder="Ex: Av Paulista, SP", default_text="Avenida Paulista, SP")
        self.input_map.on_submit = lambda _: self._on_load_map_clicked()
        self.real_map_components.append(self.input_map)

        # Atalhos rápidos de locais conhecidos (carregamento instantâneo)
        ym += 30
        self.btn_preset_paulista = Button(x, ym, 65, 22, "Paulista", lambda: self._load_preset("Avenida Paulista, SP"), bg_color=(38, 46, 60))
        self.btn_preset_copa = Button(x + 68, ym, 65, 22, "Copa RJ", lambda: self._load_preset("Copacabana, Rio de Janeiro"), bg_color=(38, 46, 60))
        self.btn_preset_times = Button(x + 136, ym, 69, 22, "Times Sq", lambda: self._load_preset("Times Square, New York"), bg_color=(38, 46, 60))
        self.real_map_components.extend([self.btn_preset_paulista, self.btn_preset_copa, self.btn_preset_times])

        ym += 26
        self.btn_load_map = Button(x, ym, 205, 28, "Carregar Mapa Real", self._on_load_map_clicked, bg_color=(24, 115, 175), icon="🌐")
        self.real_map_components.append(self.btn_load_map)

        # Espaço reservado para mensagem de status do carregamento (y: 124 a 144)
        ym += 48
        map_algos = ["A*", "Dijkstra"]
        self.dd_map_algo = Dropdown(x, ym, 205, 26, map_algos, self._on_map_algo_select, label="Busca")
        self.real_map_components.append(self.dd_map_algo)

        ym += 32
        self.btn_map_play = Button(x, ym, 48, 26, "Play", self._map_play, bg_color=(0, 150, 136), icon="▶")
        self.btn_map_step = Button(x + 51, ym, 48, 26, "Passo", self._map_step, bg_color=(60, 110, 180), icon="⏯")
        self.btn_map_instant = Button(x + 102, ym, 52, 26, "Direto", self._map_instant, bg_color=(125, 60, 155), icon="⚡")
        self.btn_map_reset = Button(x + 157, ym, 48, 26, "Reset", self._map_reset, bg_color=(190, 50, 60), icon="↺")
        self.real_map_components.extend([self.btn_map_play, self.btn_map_step, self.btn_map_instant, self.btn_map_reset])

        ym += 36
        self.sld_map_speed = Slider(x, ym, 205, 16, 1, 50, 5, self._on_map_speed_change, label="Velocidade (Passos)")
        self.real_map_components.append(self.sld_map_speed)

        ym += 28
        self.btn_map_auto_ends = Button(x, ym, 205, 26, "Auto Início / Fim", self._map_auto_ends, bg_color=(52, 73, 94), icon="🎯")
        self.real_map_components.append(self.btn_map_auto_ends)

        ym += 30
        self.btn_map_nav = Button(x, ym, 100, 26, "Navegar", self._map_toggle_nav, bg_color=(37, 99, 235), icon="🚗")
        self.btn_map_names = Button(x + 105, ym, 100, 26, "Nomes: ON", self._map_toggle_names, bg_color=(45, 55, 72), icon="🏷")
        self.real_map_components.extend([self.btn_map_nav, self.btn_map_names])

        ym += 30
        self.btn_map_center = Button(x, ym, 205, 26, "Centralizar Visão", self._map_center_view, bg_color=(44, 62, 80), icon="⌖")
        self.real_map_components.append(self.btn_map_center)

        self._refresh_components_list()

    def _refresh_components_list(self):
        """Atualiza a lista ativa de componentes de acordo com o modo."""
        active = self.maze_components if self.app_mode == "MAZE" else self.real_map_components
        self.components = [self.btn_toggle, self.btn_tab_maze, self.btn_tab_map] + active

    def set_app_mode(self, mode_name: str):
        """Alterna suavemente entre o Modo Labirinto e o Modo Mapa Real Vetorial."""
        if mode_name not in ("MAZE", "REAL_MAP"):
            return
        self.app_mode = mode_name

        # Fecha menus suspensos abertos
        for c in self.maze_components + self.real_map_components:
            if isinstance(c, Dropdown):
                c.is_open = False

        if self.app_mode == "MAZE":
            self.btn_tab_maze.bg_color = (0, 150, 185)
            self.btn_tab_maze.text_color = (255, 255, 255)
            self.btn_tab_map.bg_color = (35, 40, 52)
            self.btn_tab_map.text_color = (180, 190, 205)
            if self.grid:
                self.grid.needs_recentering = True
        else:
            self.btn_tab_maze.bg_color = (35, 40, 52)
            self.btn_tab_maze.text_color = (180, 190, 205)
            self.btn_tab_map.bg_color = (0, 150, 185)
            self.btn_tab_map.text_color = (255, 255, 255)

        self._refresh_components_list()

        # Se entrar no modo Mapa Real e ainda não houver mapa carregado, carrega o preset padrão
        if self.app_mode == "REAL_MAP" and self.real_map and not self.real_map.nodes:
            self._load_preset("Avenida Paulista, SP")

    def toggle_collapse(self):
        self.is_collapsed = not self.is_collapsed
        self.btn_toggle.text = "+" if self.is_collapsed else "—"

    # --- Callbacks do Mapa Real Vetorial ---
    def _load_preset(self, location_name: str):
        if hasattr(self, 'input_map'):
            self.input_map.text = location_name
            self.input_map.cursor_pos = len(location_name)
        self._on_load_map_clicked()

    def _on_load_map_clicked(self):
        if self.map_thread and self.map_thread.is_alive():
            return
        query = self.input_map.text.strip() if hasattr(self, 'input_map') else ""
        if not query:
            self.map_status = "Digite um local primeiro!"
            self.map_status_color = (241, 196, 15)
            return

        self.map_status = "Buscando no OpenStreetMap..."
        self.map_status_color = (0, 180, 216)
        self.btn_load_map.text = "Carregando..."
        self.map_thread = MapLoadThread(query, radius_meters=550)
        self.map_thread.start()

    def _on_map_algo_select(self, algo_name: str):
        if self.real_map:
            self.real_map.set_algorithm(algo_name)

    def _on_map_speed_change(self, val: float):
        self.real_map_speed = max(1, int(val))

    def _map_play(self):
        if not self.real_map:
            return
        if self.real_map.is_running:
            self.real_map.is_running = False
            self.btn_map_play.text = "Play"
        else:
            if self.real_map.is_finished:
                self.real_map.reset_pathfinding()
            self.real_map.start_pathfinding()
            self.btn_map_play.text = "Pausar"

    def _map_step(self):
        if self.real_map:
            if not self.real_map.is_running and not self.real_map.is_finished:
                self.real_map.start_pathfinding()
            self.real_map.step_pathfinding(max_steps=max(1, int(self.real_map_speed)))

    def _map_instant(self):
        if self.real_map:
            self.real_map.solve_instant()
            self.btn_map_play.text = "Play"

    def _map_reset(self):
        if self.real_map:
            self.real_map.reset_pathfinding()
            self.btn_map_play.text = "Play"

    def _map_auto_ends(self):
        if self.real_map:
            self.real_map._auto_select_start_end()
            self.real_map.reset_pathfinding()

    def _map_center_view(self):
        if self.real_map:
            self.real_map.pan_x = 0.0
            self.real_map.pan_y = 0.0

    def _map_toggle_nav(self):
        if self.real_map:
            self.real_map.toggle_navigation()
            is_nav = getattr(self.real_map, 'simulating_navigation', False)
            if hasattr(self, 'btn_map_nav'):
                self.btn_map_nav.text = "Pausar GPS" if is_nav else "Navegar"

    def _map_toggle_names(self):
        if self.real_map:
            self.real_map.toggle_street_names()
            show = getattr(self.real_map, 'show_street_names', True)
            if hasattr(self, 'btn_map_names'):
                self.btn_map_names.text = "Nomes: ON" if show else "Nomes: OFF"

    # --- Callbacks do Labirinto Clássico ---
    def _on_view_mode_change(self, mode_str: str):
        if not self.renderer:
            return
        mode_map = {"2D Clássico": "2D", "3D Orbital": "3D_ORBIT", "1ª Pessoa": "FIRST_PERSON"}
        key = mode_map.get(mode_str, "2D")
        self.renderer.set_view_mode(key)
        show = getattr(self.renderer, 'show_minimap', True)
        if hasattr(self, 'btn_minimap'):
            self.btn_minimap.text = "Minimapa: ON" if show else "Minimapa: OFF"

    def _toggle_minimap(self):
        if not self.renderer:
            return
        self.renderer.toggle_minimap()
        show = getattr(self.renderer, 'show_minimap', True)
        self.btn_minimap.text = "Minimapa: ON" if show else "Minimapa: OFF"

    def set_tool(self, tool_mode: str):
        self.active_tool = tool_mode

    def _prev_pair_id(self):
        self._set_pair_id(self.current_pair_id - 1)

    def _next_pair_id(self):
        self._set_pair_id(self.current_pair_id + 1)

    def _set_pair_id(self, new_id: int):
        self.current_pair_id = max(1, min(8, new_id))
        if hasattr(self, 'btn_pair_display'):
            self.btn_pair_display.text = f"Par: {self.current_pair_id}"
            new_col = getattr(config, 'get_pair_color', lambda p: (0, 210, 211))(self.current_pair_id)
            self.btn_pair_display.bg_color = new_col
            self.btn_pair_display.hover_color = new_col
        mgr = getattr(self, 'interactive_mgr', None) or getattr(self.grid, 'interactive_mgr', None)
        if mgr:
            mgr.current_pair_id = self.current_pair_id

    def _clear_all_maze(self):
        if hasattr(self.grid, 'fill_empty'):
            self.grid.fill_empty()
        mgr = getattr(self, 'interactive_mgr', None) or getattr(self.grid, 'interactive_mgr', None)
        if mgr and hasattr(mgr, 'clear'):
            mgr.clear()
        if hasattr(self.pathfinding, 'reset'):
            self.pathfinding.reset()

    def _set_custom_rows(self, val):
        self.custom_rows = int(val)

    def _set_custom_cols(self, val):
        self.custom_cols = int(val)

    def _apply_custom_size(self):
        self._clear_all_maze()
        self.grid.resize(self.custom_rows, self.custom_cols)
        self._clear_all_maze()

    def _on_size_select(self, option: str):
        is_custom = "Personalizado" in option
        self.sld_rows.visible = is_custom
        self.sld_cols.visible = is_custom
        self.btn_apply_size.visible = is_custom
        if "Pequeno" in option:
            self._clear_all_maze()
            self.grid.resize(15, 20)
            self._clear_all_maze()
        elif "Médio" in option:
            self._clear_all_maze()
            self.grid.resize(30, 40)
            self._clear_all_maze()
        elif "Grande" in option:
            self._clear_all_maze()
            self.grid.resize(50, 60)
            self._clear_all_maze()

    def _run_generator(self, gen_name: str):
        self._clear_all_maze()
        if gen_name == "DFS Generator":
            self.generator.generate_dfs()
        elif gen_name == "Prim":
            self.generator.generate_prim()
        elif gen_name == "Divisao Recursiva":
            self.generator.generate_recursive_division()
        elif gen_name == "Caos":
            self.generator.generate_chaos()

    # --- Eventos e Atualização ---
    def handle_event(self, event):
        if self.btn_toggle.handle_event(event):
            return True
        if self.is_collapsed:
            return False

        # Abas sempre têm prioridade de clique
        if self.btn_tab_maze.handle_event(event):
            return True
        if self.btn_tab_map.handle_event(event):
            return True

        # Dropdown aberto tem prioridade exclusiva
        open_dd = next((c for c in self.components if isinstance(c, Dropdown) and c.is_open), None)
        if open_dd:
            if open_dd.handle_event(event):
                return True

        # Prioridade para o campo de texto se estiver ativo
        if self.app_mode == "REAL_MAP" and hasattr(self, 'input_map'):
            if self.input_map.handle_event(event):
                return True

        # Interação com componentes ativos
        for comp in reversed(self.components):
            if comp in (self.btn_toggle, self.btn_tab_maze, self.btn_tab_map):
                continue
            if isinstance(comp, Dropdown):
                was_open = comp.is_open
                if comp.handle_event(event):
                    if comp.is_open and not was_open:
                        for other in self.components:
                            if isinstance(other, Dropdown) and other != comp:
                                other.is_open = False
                    return True
            else:
                if comp.handle_event(event):
                    return True

        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            if event.pos[0] <= self.sidebar_width:
                return True
        return False

    def update(self, delta_time: float = 0.0):
        mouse_pos = pygame.mouse.get_pos()
        self.btn_toggle.update_hover(mouse_pos)

        if not self.is_collapsed:
            self.btn_tab_maze.update_hover(mouse_pos)
            self.btn_tab_map.update_hover(mouse_pos)

            if self.app_mode == "REAL_MAP" and hasattr(self, 'input_map'):
                self.input_map.update()

            open_dd = next((c for c in self.components if isinstance(c, Dropdown) and c.is_open), None)
            popup_rect = open_dd.get_popup_rect() if open_dd else None

            for comp in self.components:
                if comp in (self.btn_toggle, self.btn_tab_maze, self.btn_tab_map):
                    continue
                if popup_rect and popup_rect.collidepoint(mouse_pos) and comp != open_dd:
                    comp.is_hovered = False
                else:
                    comp.update_hover(mouse_pos)

        # Monitora a thread assíncrona do mapa
        if self.map_thread:
            if self.map_thread.is_alive():
                dots = "." * (int(time.time() * 3) % 4)
                self.map_status = f"Baixando ruas OSM{dots}"
                self.map_status_color = (0, 200, 255)
            elif self.map_thread.done:
                if self.map_thread.result:
                    nodes, edges, lat, lon = self.map_thread.result
                    if self.real_map:
                        self.real_map.load_graph(nodes, edges, location_name=self.input_map.text.strip(),
                                                 center_lat=lat, center_lon=lon)
                    self.map_status = f"✓ {len(nodes)} nós carregados!"
                    self.map_status_color = (46, 204, 113)
                    # Muda automaticamente para a aba do Mapa Real
                    self.set_app_mode("REAL_MAP")
                elif self.map_thread.error:
                    err = self.map_thread.error
                    self.map_status = f"⚠ {err[:28]}..." if len(err) > 30 else f"⚠ {err}"
                    self.map_status_color = (231, 76, 60)

                self.btn_load_map.text = "Carregar Mapa Real"
                self.map_thread = None

        # Executa passos contínuos da busca ou simulação de GPS no mapa vetorial
        if self.app_mode == "REAL_MAP" and self.real_map:
            if self.real_map.is_running:
                self.real_map.step_pathfinding(max_steps=max(1, int(self.real_map_speed)))
                if self.real_map.is_finished:
                    self.btn_map_play.text = "Play"

            if getattr(self.real_map, 'simulating_navigation', False):
                self.real_map.update_navigation(delta_time)
                if hasattr(self, 'btn_map_nav') and not self.real_map.simulating_navigation:
                    self.btn_map_nav.text = "Navegar"

    def draw(self, surface):
        curr_width = self.collapsed_width if self.is_collapsed else self.sidebar_width

        sidebar_bg = pygame.Surface((curr_width, self.height), pygame.SRCALPHA)
        sidebar_bg.fill((18, 20, 26, 242))
        surface.blit(sidebar_bg, (0, 0))
        pygame.draw.line(surface, (45, 52, 64), (curr_width, 0), (curr_width, self.height), 2)

        self.btn_toggle.draw(surface)

        if not self.is_collapsed:
            # Abas
            self.btn_tab_maze.draw(surface)
            self.btn_tab_map.draw(surface)

            # Componentes normais
            for comp in self.components:
                if comp not in (self.btn_toggle, self.btn_tab_maze, self.btn_tab_map) and not isinstance(comp, Dropdown):
                    comp.draw(surface)

            # Informações específicas do modo
            if self.app_mode == "REAL_MAP":
                # Status de carregamento
                font_st = pygame.font.SysFont("Segoe UI", 10)
                st_surf = font_st.render(self.map_status, True, self.map_status_color)
                surface.blit(st_surf, (12, 126))

                # Cartão de Estatísticas do Mapa Real
                self._draw_real_map_stats(surface)
            else:
                # Cartão de Estatísticas do Labirinto
                self._draw_stats_card(surface)

            # Cabeçalhos de Dropdowns
            for comp in self.components:
                if isinstance(comp, Dropdown):
                    comp.draw_header(surface)

            # Popups flutuantes (topo absoluto)
            open_dd = next((c for c in self.components if isinstance(c, Dropdown) and c.is_open), None)
            if open_dd:
                open_dd.draw_popup(surface)

    def _draw_stats_card(self, surface):
        card_rect = pygame.Rect(10, self.height - 95, 210, 85)
        pygame.draw.rect(surface, (25, 29, 36), card_rect, border_radius=8)
        pygame.draw.rect(surface, (45, 52, 65), card_rect, width=1, border_radius=8)

        font_title = pygame.font.SysFont("Segoe UI", 11, bold=True)
        font_data = pygame.font.SysFont("Segoe UI", 11)

        title_surf = font_title.render("ESTATÍSTICAS LABIRINTO", True, (0, 180, 216))
        surface.blit(title_surf, (card_rect.x + 8, card_rect.y + 6))

        stats = [
            f"Tamanho: {self.grid.rows}x{self.grid.cols}",
            f"Nos Visitados: {getattr(self.pathfinding, 'visited_count', 0)}",
            f"Rota: {getattr(self.pathfinding, 'path_length', 0)}",
            f"Ferramenta: {self.active_tool}"
        ]
        for i, stat in enumerate(stats):
            stat_surf = font_data.render(stat, True, (200, 205, 215))
            surface.blit(stat_surf, (card_rect.x + 8, card_rect.y + 22 + (i * 14)))

    def _draw_real_map_stats(self, surface):
        card_rect = pygame.Rect(10, self.height - 110, 210, 100)
        pygame.draw.rect(surface, (25, 29, 36), card_rect, border_radius=8)
        pygame.draw.rect(surface, (0, 160, 210), card_rect, width=1, border_radius=8)

        font_title = pygame.font.SysFont("Segoe UI", 11, bold=True)
        font_data = pygame.font.SysFont("Segoe UI", 10)

        title_surf = font_title.render("DADOS MAPA REAL (OSM)", True, (0, 190, 235))
        surface.blit(title_surf, (card_rect.x + 8, card_rect.y + 6))

        rm = self.real_map
        num_nodes = len(rm.nodes) if rm else 0
        num_edges = len(rm.edges) if rm else 0
        visited = len(rm.visited_nodes) if rm else 0
        dist_m = rm.total_path_distance if rm else 0.0

        stats = [
            f"Nós: {num_nodes}  |  Vias: {num_edges}",
            f"Início: {'Definido' if (rm and rm.start_node) else 'Pendente'}",
            f"Destino: {'Definido' if (rm and rm.end_node) else 'Pendente'}",
            f"Explorados: {visited} nós",
            f"Distância: {dist_m:.0f}m ({dist_m / 1000.0:.2f}km)" if dist_m > 0 else "Distância: --"
        ]
        for i, stat in enumerate(stats):
            stat_surf = font_data.render(stat, True, (200, 205, 215))
            surface.blit(stat_surf, (card_rect.x + 8, card_rect.y + 22 + (i * 15)))
