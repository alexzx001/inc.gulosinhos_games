"""
Ultimate Maze Sandbox - Configuration File
Este arquivo armazena todas as constantes globais do projeto:
dimensões de tela, paleta de cores, estados de células, atalhos de teclado e configurações de interface.
"""

import pygame

# ==========================================
# 1. CONFIGURAÇÕES DE JANELA E DESEMPENHO
# ==========================================
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60
WINDOW_TITLE = "Ultimate Maze Sandbox - inc.gulosinhos_games"

# ==========================================
# 2. CONFIGURAÇÕES DA GRADE E CÂMERA (GRID & CAMERA)
# ==========================================
DEFAULT_GRID_ROWS = 30
DEFAULT_GRID_COLS = 50
MIN_GRID_SIZE = 10
MAX_GRID_SIZE = 200

CELL_SIZE = 20  # Tamanho base do quadrado em pixels (escalável pela câmera)

# Câmera / Zoom
MIN_ZOOM = 0.2
MAX_ZOOM = 5.0
ZOOM_SPEED = 0.1

# ==========================================
# 3. PALETA DE CORES (RGB)
# ==========================================
COLOR_BG = (18, 18, 24)           # Fundo geral da aplicação
COLOR_PANEL_BG = (28, 28, 38)     # Fundo dos painéis de UI
COLOR_GRID_LINE = (40, 40, 50)    # Linhas da grade

# Tipos de Células / Terrenos
COLOR_EMPTY = (245, 245, 245)      # Caminho livre / Célula vazia
COLOR_WALL = (30, 30, 35)         # Parede
COLOR_START = (46, 204, 113)      # Ponto Inicial (Verde)
COLOR_END = (231, 76, 60)         # Ponto Final / Saída (Vermelho)
COLOR_WAYPOINT = (241, 196, 15)   # Checkpoints / Waypoints (Amarelo)
COLOR_KEY = (230, 126, 34)        # Chave (Laranja)
COLOR_DOOR = (142, 68, 173)       # Porta Trancada (Roxo)
COLOR_PORTAL = (52, 152, 219)     # Portal / Wormhole (Azul Claro)
COLOR_HAZARD = (192, 57, 43)      # Inimigo / Raio de Visão (Vermelho Escuro)

# Visualização de Algoritmos (Heatmap & Path)
COLOR_VISITED = (174, 214, 241)   # Nós Visitados (Azul Suave)
COLOR_OPEN = (212, 239, 223)      # Nós na Fila / Abertos (Verde Claro)
COLOR_PATH = (243, 156, 18)       # Caminho Final Encontrado (Dourado)
COLOR_FOG = (10, 10, 15)          # Nevoeiro da Guerra (Fog of War)

# Cores de UI e Texto
COLOR_TEXT = (236, 240, 241)
COLOR_TEXT_DIM = (149, 165, 166)
COLOR_BTN_NORMAL = (52, 73, 94)
COLOR_BTN_HOVER = (41, 128, 185)
COLOR_BTN_ACTIVE = (39, 174, 96)

# Paleta de Cores para Pares de Chave e Porta (1 a 8)
PAIR_COLORS = {
    1: (0, 210, 211),    # Turquesa / Ciano Vivo
    2: (255, 159, 67),   # Âmbar / Ouro
    3: (165, 94, 234),   # Roxo / Lavanda
    4: (38, 222, 129),   # Verde Esmeralda
    5: (252, 92, 101),   # Coral / Vermelho
    6: (69, 170, 242),   # Azul Céu
    7: (253, 121, 168),  # Rosa Pink
    8: (254, 211, 48),   # Amarelo Solar
}


def get_pair_color(pair_id: int) -> tuple:
    """Retorna uma cor contrastante para o par de chave/porta especificado."""
    try:
        pair_id = int(pair_id)
    except (ValueError, TypeError):
        pair_id = 1
    if pair_id in PAIR_COLORS:
        return PAIR_COLORS[pair_id]
    import colorsys
    hue = ((pair_id * 0.618033988749895) % 1.0)
    rgb = colorsys.hsv_to_rgb(hue, 0.85, 0.95)
    return (int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255))

# ==========================================
# 4. ESTADOS DAS CÉLULAS (CELL TYPES)
# ==========================================
TYPE_EMPTY = "EMPTY"
TYPE_WALL = "WALL"
TYPE_START = "START"
TYPE_END = "END"
TYPE_WAYPOINT = "WAYPOINT"
TYPE_KEY = "KEY"
TYPE_DOOR = "DOOR"
TYPE_PORTAL = "PORTAL"
TYPE_HAZARD = "HAZARD"

# ==========================================
# 5. ATALHOS DE TECLADO (KEYBINDINGS)
# ==========================================
KEY_PAN = pygame.K_SPACE          # Segurar para mover a câmera
KEY_RESET = pygame.K_r            # Limpar busca
KEY_CLEAR_ALL = pygame.K_c        # Limpar mapa inteiro
KEY_PLAY = pygame.K_RETURN        # Executar algoritmo
KEY_TOGGLE_3D = pygame.K_F3       # Alternar modo 2D / 3D
KEY_TOGGLE_FOG = pygame.K_f      # Alternar Nevoeiro da Guerra

# ==========================================
# 6. CONFIGURAÇÕES DE SIMULAÇÃO E INTERFACE
# ==========================================
DEFAULT_SPEED = 50                # Passos por segundo (FPS do algoritmo)
MAX_SPEED = 500
MIN_SPEED = 1

UI_SIDEBAR_WIDTH = 280            # Largura do menu lateral de ferramentas